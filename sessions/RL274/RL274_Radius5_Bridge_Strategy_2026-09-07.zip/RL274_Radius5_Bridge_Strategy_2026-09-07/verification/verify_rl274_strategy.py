#!/usr/bin/env python3
from itertools import product
from math import gcd

def windows(x,m):
    A=len(x)
    return [sum(x[(i+j)%A] for j in range(m)) for i in range(A)]

def optimal_flows(x,m):
    A=len(x); L=sum(x)
    W=windows(x,m)
    # Any q produces a valid integer flow q-W_i; only nearby q can minimize L1.
    candidates=[]
    for q in range(-1,m+2):
        g=[q-w for w in W]
        candidates.append((sum(abs(v) for v in g),q,g,A*q-m*L))
    best=min(v[0] for v in candidates)
    return [v for v in candidates if v[0]==best]

def zero_count(x,s,r):
    A=len(x)
    return sum(1-x[(s+j)%A] for j in range(r))

checks=0
disc_checks=0
even_checks=0

for A in range(4,10):
    for bits in product((0,1), repeat=A):
        L=sum(bits)
        if L==0 or L==A:
            continue
        x=list(bits)
        for m in range(1,A):
            opts=optimal_flows(x,m)
            R=opts[0][0]
            for _,q,g,kappa in opts:
                # transport normal form and parity
                if kappa>=0:
                    beta=sum(max(-v,0) for v in g)
                    assert R==kappa+2*beta
                assert R%2==kappa%2
                assert kappa%gcd(A,L)==0
                if A%2==0 and L%2==0:
                    assert R%2==0
                    even_checks+=1
                checks+=1

                # exact determinant-discrepancy identity for small c,d choices
                if kappa<=0:
                    continue
                z=A-L
                B=m-q
                for d in range(1,5):
                    for c in range(0,5):
                        H=d*z-c*A
                        if not (0 < H < A//gcd(A,m)):
                            continue
                        n=d*B-c*m
                        assert H*m == n*A + d*kappa
                        assert H*B == n*z + c*kappa
                        beta=sum(max(-v,0) for v in g)
                        for s in range(A):
                            lhs=zero_count(x,s,d*kappa)
                            rhs=c*kappa+sum(g[(s+j*m)%A] for j in range(H))
                            assert lhs==rhs
                            assert abs(2*lhs-kappa*(2*c+1)) <= R
                            disc_checks+=1

# Doubling inequality for cyclic window flows where 2m<A.
double_checks=0
for A in range(5,12):
    for bits in product((0,1), repeat=A):
        x=list(bits)
        for m in range(1,(A-1)//2+1):
            if 2*m>=A: continue
            Wm=windows(x,m); W2=windows(x,2*m)
            for q in range(0,m+1):
                g=[q-w for w in Wm]
                D=[2*q-w for w in W2]
                for i in range(A):
                    assert D[i]==g[i]+g[(i+m)%A]
                bg=sum(max(-v,0) for v in g)
                bD=sum(max(-v,0) for v in D)
                assert bD <= 2*bg
                double_checks+=1

print("RL274 strategy verifier: PASS")
print("transport_checks=", checks)
print("even_parity_checks=", even_checks)
print("determinant_discrepancy_checks=", disc_checks)
print("doubling_checks=", double_checks)
