# RL218 scratch result — exact legal backward-word algebra and RL-lattice pullback

Status: **NOT PROMOTED**.  This is proof-quality scratch work for RL218; it does
not alter `authoritative/` or a frozen session.

## 1. Map and raw-word normal form

Use the shortcut Collatz map

\[
T(n)=\begin{cases}n/2,&n\text{ even},\\(3n+1)/2,&n\text{ odd}.
\end{cases}
\]

Its two backward moves are

\[
D(Y)=2Y,\qquad O(Y)=(2Y-1)/3.
\]

The move `D` is always legal.  For a positive integer `Y`, `O` is legal iff
`Y=2 (mod 3)`; its output is then a positive odd integer and maps forward in
one shortcut step to `Y`.

Let `w=(w_1,...,w_n)` be a raw word in `{D,O}`, applied from left to right to
a seed `s`.  Let `h_i` be the number of `O` letters among the first `i`
letters.  Define

\[
C_0=0,\qquad
C_i=\begin{cases}
2C_{i-1},&w_i=D,\\
2C_{i-1}+3^{h_{i-1}},&w_i=O.
\end{cases}
\]

Then after `i` letters the formal value is

\[
Y_i={2^i s-C_i\over 3^{h_i}},
\]

and, if the word has `h` odd-inverse letters,

\[
C_w=\sum_{i:w_i=O}2^{n-i}3^{h_{i-1}},\qquad
W(s)={2^n s-C_w\over3^h}.                 \tag{1}
\]

**Terminal-legality lemma.**  For positive integral `s`, the whole raw word
is legal iff

\[
3^h\mid 2^n s-C_w.                         \tag{2}
\]

Thus the apparently separate congruence at every `O` step is equivalent to
one terminal congruence.  To prove the nontrivial direction, strip the word
from the right.  A final `D` only multiplies the numerator by `2`, a unit
modulo every power of `3`.  Across a final `O`,
`N_i=2N_{i-1}-3^{h-1}`; divisibility of `N_i` by `3^h` implies divisibility
of `N_{i-1}` by `3^{h-1}`.  Iteration gives integrality at every earlier odd
inverse.  Starting from positive `s`, every integral odd inverse is positive
because its input is a positive integer congruent to `2 mod 3`.

Equation (2) is one residue class of the seed:

\[
s=2^{-n}C_w\pmod {3^h}.                    \tag{3}
\]

## 2. Dyadic-tower / odd-only form

Every word with at least one `O` has a unique decomposition

\[
D^{e_1-1}O\ D^{e_2-1}O\cdots D^{e_h-1}O\ D^t,
\]

where `e_i>=1` and `t>=0`.  Put

\[
E_j=e_1+\cdots+e_j,
\]

and define

\[
Q_0=0,\qquad Q_j=2^{e_j}Q_{j-1}+3^{j-1}.  \tag{4}
\]

Equivalently,

\[
Q_h=\sum_{j=1}^h3^{j-1}2^{e_{j+1}+\cdots+e_h}. \tag{5}
\]

After the `j`-th odd inverse,

\[
x_j={2^{E_j}s-Q_j\over3^j},                \tag{6}
\]

and the final output is `2^t x_h`.  The whole word is legal iff

\[
3^h\mid2^{E_h}s-Q_h,
\quad\text{equivalently}\quad
s=2^{-E_h}Q_h\pmod {3^h}.                  \tag{7}
\]

If the seed is exactly certified to reach `1`, a legal output is exactly
certified blue: its deterministic forward orbit traverses the raw word in
reverse and then follows the seed certificate.

Every even certified seed `s=2^a s_o` can be replaced by its certified odd
core `s_o` while increasing `e_1` by `a`.  This leaves `Q_h` unchanged.
Hence it is lossless to use an odd seed.  For an odd output `y`, (6) becomes

\[
2^E s=3^h y+Q_h,\qquad
E=v_2(3^h y+Q_h),                           \tag{8}
\]

where `E=E_h` and `s` is odd.  Conversely, if the valuation equality in (8)
holds and `s=(3^h y+Q_h)/2^E`, then (7) holds and the entire reverse word is
legal.  Thus (8), not divisibility alone, is the exact canonical branch test.

## 3. Substitute the RL217 root lattice

For a fixed H21 prefix write

\[
y(k)=y_*+3\,2^{58}k.                        \tag{9}
\]

These are odd roots.  They also satisfy `y(k)=2 mod 3`: the inherited
root-unit conditions say both `y(k)` and `y(k)+K0` are units modulo `3`, while
`K0=2^37=2 mod 3`, forcing `y(k)=2 mod 3`.

Because every `y(k)` is odd, a backward word hitting it cannot have a trailing
dyadic tower: in the decomposition above one must have `t=0`.  If there is no
odd inverse at all, only the identity word can hit an odd root.  Hence the
nontrivial recognition problem is exactly the `h>=1`, `t=0` case below.

Fix an exponent word `(e_1,...,e_h)` and put

\[
A=3^h y_*+Q_h,\qquad C=3^{h+1}.             \tag{10}
\]

Then its canonical odd endpoint is controlled by

\[
N(k)=3^h y(k)+Q_h=A+C2^{58}k.               \tag{11}
\]

Let `nu=v2(A)`.

### Low-valuation case: `nu<58`

The valuation of (11) is `nu` for every integer `k`.  Therefore the prescribed
word can end at an odd seed iff `E=nu`; when it does, **every** `k` follows
that same exact exponent word, but to the varying endpoint

\[
s(k)=A/2^E+C2^{58-E}k.                      \tag{12}
\]

### High-valuation case: `nu>=58`

Write `a=A/2^58`.  No canonical word with `E<58` is possible.  For
`E=58+d`, `d>=0`, exact valuation is equivalent to the single residue class

\[
k=\kappa_d\pmod {2^{d+1}},\qquad
\kappa_d=C^{-1}(2^d-a)\pmod {2^{d+1}}.      \tag{13}
\]

Writing `k=kappa_d+2^(d+1) ell`, the odd endpoints form the affine lattice

\[
s(k)=s_0+2C\ell,\qquad
s_0=(a+C\kappa_d)/2^d.                      \tag{14}
\]

Equations (12)--(14) are the exact valuation/congruence/lattice action asked
for in the RL218 target.

## 4. Fixed certified seed versus a varying endpoint

For one fixed odd certified seed `s`, exact membership is

\[
A+C2^{58}k=2^E s,
\]

so there is at most one lattice parameter:

\[
k={2^E s-A\over C2^{58}}.                   \tag{15}
\]

It exists exactly when the numerator is divisible by `3^(h+1) 2^58`, and it
must then pass the prefix range, terminal-Hensel exclusions and phase-51
selector.  Equivalently the fixed seed must satisfy

\[
2^E s=A\pmod {2^{58}},
\qquad
s=2^{-E}(Q_h+3^h y_*)\pmod {3^{h+1}}.       \tag{16}
\]

Legality alone fixes `s mod 3^h`; membership in the RL root lattice adds
exactly the next ternary digit (`y_*=2 mod 3`).

This gives a precise quantifier barrier.  The congruence in (13) recognizes
candidates sharing a legal word to **some endpoint `s(k)`**.  It does not say
those varying endpoints are blue.  Applying one fixed word to one fixed blue
seed gives the singleton (15), never a non-singleton `k` class.  For a finite
seed set and finite word set the pullback is a finite union of such exact
singletons.  A whole `k` progression can be certified only if an independent
theorem/certificate proves the corresponding endpoint progression in (12) or
(14) blue.  Treating endpoint integrality as endpoint certification would be
the forbidden congruence-versus-equality promotion.

There is nevertheless a positive exact use.  If an interval `[1,B]` is
certified, then the linear inequalities `1<=s(k)<=B` applied to (12), or to
(14) after (13), certify the full resulting `k` interval/residue intersection
without enumerating its members.  More generally a certified finite union of
endpoint progressions pulls back by elementary affine-lattice intersection.

## 5. Intersection with the phase-51 selector

A phase-51 cylinder `x=R mod 2^q` (`13<=q<=25`) is, for a prefix with base
`eta_*`, exactly

\[
k=\rho\pmod {2^q},\qquad
\rho=(R-\eta_*)(3^{17})^{-1}\pmod {2^q}.    \tag{17}
\]

In the low-valuation case (12), the word adds no `k` congruence.  In the
high-valuation case, combine (13) and (17): the intersection is empty unless

\[
\kappa_d=\rho\pmod {2^{\min(d+1,q)}},        \tag{18}
\]

and otherwise it is one class modulo `2^max(d+1,q)`.  The inherited `k`
windows have length less than `2^13`, so each individual phase cylinder
contains at most one `k` in a prefix window.  Terminal-Hensel exclusions then
remove their listed exact values.  This is an exact modular consumer; no scan
of 139,581,280 candidates is required.

## 6. Exact exclusion of the inherited RL80 analytic blue comb

RL80 proved the analytic family

\[
B(j,n)={2^j(2^n+1)\over3^j}-1,
\]

for odd `n` and `1<=j<=v3(2^n+1)`.  It follows immediately that

\[
v_2(B(j,n)+1)=j.                            \tag{19}
\]

Suppose `B(j,n)=y_*+3*2^58 k` in an authoritative positive `k` window.  Exact
reconstruction of all 45,046 inherited prefix bases gives

\[
2\le v_2(y_*+1)\le15<58.
\]

Hence (19) pins `j=v2(y_*+1)`, independently of `k`.  Rearranging the equality
gives

\[
2^n=3^j{y_*+1\over2^j}-1
     +3^{j+1}2^{58-j}k.                    \tag{20}
\]

All authoritative `k` windows are positive, so their roots exceed `2^59`;
also `B(j,n)+1<=2^n`.  Thus `n>=58-j`, and (20) has the necessary condition

\[
3^j{y_*+1\over2^j}-1=0\pmod {2^{58-j}}.    \tag{21}
\]

The scratch verifier independently reconstructs every prefix base and finds
that (21) fails for **all 45,046** bases, including the prefix already deleted
by RL216.  Its prefix-row digest is
`24a57291eaf8685ff84f8e2ebe02b751a5597b84a86d4d9140d2f3bfb7b4dd90`,
and its `(Q,j,screen-residue)` digest is
`bca5aecb93b3b4c1d9c64e42fac6b37452b64409d401008d202d2559710b57e2`.
Therefore no member of the RL80 LTE blue comb lies in any RL217
root progression in its authoritative positive window.  Because RL roots are
odd, dyadic multiples of comb nodes cannot help.

Classification: (1)--(18) are analytic algebra.  The zero-survivor statement
from (21) is an **exact finite certificate candidate**, not an analytic global
Collatz theorem.  It removes no RL217 candidate by itself; it exactly closes
the explicit RL80 comb as a source of candidate membership.

## 7. Caveats and route decision supplied by this subtask

- A residue match in (13), (17) or (18) is branch legality, not blue membership.
- A fixed certified node plus fixed word gives only (15), an exact singleton.
- Arbitrary backward closure remains cycle-intersection neutral under RL80; the
  algebra here is useful only as an equality-level recognition consumer.
- The LTE-comb exclusion concerns RL80's explicit analytic family, not the full
  certified basin and not arbitrary legal backward words.
- A serious continuation needs a compressed certificate for a whole endpoint
  set in (12)/(14), or exact fixed-seed equality hits.  Mere depth growth or
  residue coverage repeats the old quantifier failure.
