#!/usr/bin/env python3
"""Exact checks for the RL218 backward-word normal form and LTE-comb screen.

This is a scratch verifier.  It does not modify or promote proof state.
"""

import hashlib
from collections import Counter
from itertools import product


def v2(n: int) -> int:
    assert n != 0
    n = abs(n)
    return (n & -n).bit_length() - 1


def direct_word(seed: int, word: tuple[str, ...]):
    """Return (legal, output) for D:Y->2Y and O:Y->(2Y-1)/3."""
    y = seed
    for letter in word:
        if letter == "D":
            y *= 2
        else:
            if y % 3 != 2:
                return False, None
            y = (2 * y - 1) // 3
            assert y > 0 and y % 2 == 1
    return True, y


def raw_normal_form(word: tuple[str, ...]):
    """Return (n,h,c) with W(s)=(2^n s-c)/3^h."""
    c = 0
    h = 0
    for letter in word:
        if letter == "D":
            c *= 2
        else:
            c = 2 * c + 3**h
            h += 1
    return len(word), h, c


raw_checks = 0
for n in range(9):
    for word in product(("D", "O"), repeat=n):
        N, h, c = raw_normal_form(word)
        for seed in range(1, 129):
            legal, output = direct_word(seed, word)
            divisible = (2**N * seed - c) % (3**h) == 0
            assert legal == divisible
            if legal:
                assert output == (2**N * seed - c) // (3**h)
            raw_checks += 1


def grouped_q(exponents: tuple[int, ...]):
    q = 0
    for j, e in enumerate(exponents, start=1):
        q = 2**e * q + 3 ** (j - 1)
    return q


grouped_checks = 0
for h in range(1, 6):
    for exponents in product(range(1, 5), repeat=h):
        word = []
        for e in exponents:
            word.extend("D" for _ in range(e - 1))
            word.append("O")
        word = tuple(word)
        E = sum(exponents)
        q = grouped_q(exponents)
        N, h_raw, c = raw_normal_form(word)
        assert (N, h_raw, c) == (E, h, q)
        expanded = sum(
            3 ** (j - 1) * 2 ** sum(exponents[j:])
            for j in range(1, h + 1)
        )
        assert expanded == q
        for seed in range(1, 100):
            legal, output = direct_word(seed, word)
            assert legal == ((2**E * seed - q) % (3**h) == 0)
            if legal:
                assert output == (2**E * seed - q) // (3**h)
                odd_seed = seed >> v2(seed)
                canonical_E = E + v2(seed)
                assert v2(3**h * output + q) == canonical_E
                assert (3**h * output + q) // 2**canonical_E == odd_seed
            grouped_checks += 1


# Reconstruct the exact RL212/RL217 prefix bases by the same elementary recurrences
# used by the authoritative RL217 verifier, then perform a distinct consumer check.
A = 217_976_794_617
L = 137_528_045_312
K0 = 1 << 37


def b(i: int) -> int:
    return A * i // L


bs = [b(i) for i in range(17)]
csteps = [bs[i + 1] - bs[i] for i in range(16)]
states = {(0, 1)}
for i in range(1, 16):
    nxt = set()
    for height, q in states:
        shift = bs[i] - height
        for next_height in range(height + csteps[i]):
            nxt.add((next_height, 3 * q + (1 << shift)))
    states = nxt

terminal = sorted(q for height, q in states if height == 1)
assert len(terminal) == 108_950

S = 24
mod16 = 3**16
gap = mod16 * 2**13
inv16 = pow(1 << (S + 34), -1, mod16)
rows = []
for q in terminal:
    eta0 = ((1 << S) + q) * inv16 % mod16
    if eta0 % 9 not in (0, 8):
        continue
    y16 = (1 << 34) * eta0 - 1 - gap
    numerator = (1 << S) * y16 - q
    assert numerator % mod16 == 0
    y0base = numerator // mod16
    lifts = []
    for t in range(3):
        y0 = y0base + (1 << (S + 34)) * t
        if y0 % 3 and (y0 + K0) % 3:
            lifts.append((eta0 + t * mod16, y0))
    assert len(lifts) == 1
    eta, y0 = lifts[0]
    rows.append((q, eta, y0))

assert len(rows) == 45_046
assert all(y0 > 0 and y0 % 2 == 1 and y0 % 3 == 2 for _, _, y0 in rows)
row_digest = hashlib.sha256()
for q, eta, y0 in rows:
    row_digest.update(f"{q},{eta},{y0}\n".encode())
assert row_digest.hexdigest() == (
    "24a57291eaf8685ff84f8e2ebe02b751a5597b84a86d4d9140d2f3bfb7b4dd90"
)

# RL80's analytic family is
#   B(j,n)=2^j(2^n+1)/3^j-1,
# with j>=1, n odd, and j<=v3(2^n+1).  If B(j,n) lies in an RL root
# progression y0+3*2^58*k, then v2(B+1)=j.  Because every base below has
# v2(y0+1)<58, this pins j=v2(y0+1).  For the authoritative positive k
# windows, B is larger than 2^59, hence n>=58-j.  Reducing the exact equation
#   2^n = 3^j(B+1)/2^j - 1
# modulo 2^(58-j) gives the necessary base-only congruence checked below.
valuation_distribution = Counter()
comb_mod58_surviving_bases = []
screen_digest = hashlib.sha256()
for index, (q, eta, y0) in enumerate(rows):
    j = v2(y0 + 1)
    valuation_distribution[j] += 1
    assert 1 <= j < 58
    base_power_candidate = 3**j * ((y0 + 1) >> j) - 1
    modulus = 1 << (58 - j)
    screen_digest.update(f"{q},{j},{base_power_candidate % modulus}\n".encode())
    if base_power_candidate % modulus == 0:
        comb_mod58_surviving_bases.append((index, q, eta, y0, j))

expected_distribution = Counter(
    {
        2: 8458,
        3: 8458,
        4: 8458,
        5: 6768,
        6: 5078,
        7: 3388,
        8: 2098,
        9: 1208,
        10: 637,
        11: 304,
        12: 128,
        13: 46,
        14: 13,
        15: 4,
    }
)
assert valuation_distribution == expected_distribution
assert comb_mod58_surviving_bases == []
assert screen_digest.hexdigest() == (
    "bca5aecb93b3b4c1d9c64e42fac6b37452b64409d401008d202d2559710b57e2"
)

print("RL218 backward-word algebra verifier: PASS")
print(f"raw word/terminal-legality checks = {raw_checks}")
print(f"grouped word/canonical-valuation checks = {grouped_checks}")
print(f"reconstructed H21 prefix bases = {len(rows)}")
print(f"prefix-row digest = {row_digest.hexdigest()}")
print("v2(y0*+1) distribution =", sorted(valuation_distribution.items()))
print(f"LTE-comb screen digest = {screen_digest.hexdigest()}")
print("RL80 LTE-comb bases surviving necessary mod-2^58 screen = 0")
