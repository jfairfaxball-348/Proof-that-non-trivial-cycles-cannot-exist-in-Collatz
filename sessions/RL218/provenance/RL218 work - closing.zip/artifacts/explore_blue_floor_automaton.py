#!/usr/bin/env python3
"""NOT PROMOTED: exact RL218 certified-blue floor automaton exploration.

This replays the inherited RL217 height selector through phase 51.  Thereafter
it follows exact accelerated Collatz residue cylinders and removes a branch
only when every surviving RL prefix point on the branch has fallen below the
externally inherited certified-blue floor 2^71.

The prefix oracle deliberately includes the inherited terminal-Hensel misses,
so an empty remainder proves the stronger statement for a small arithmetic
superset of the authoritative RL217 candidates.
"""

import argparse
import bisect
import heapq
import json
from collections import Counter
from fractions import Fraction


A = 217_976_794_617
L = 137_528_045_312
P = 65_470_613_321
Z = L - P
K0 = 1 << 37
DELETED_Q = 43_013_953
MOD17 = 3**17
GAP = 3**16 * 2**13
BLUE_FLOOR = 1 << 71


def b(i):
    return A * i // L


def v2(n):
    n = abs(n)
    return (n & -n).bit_length() - 1


def reconstruct_records():
    bs = [b(i) for i in range(17)]
    assert bs == [0, 1, 3, 4, 6, 7, 9, 11, 12, 14, 15, 17, 19, 20, 22, 23, 25]
    increments = [bs[i + 1] - bs[i] for i in range(16)]
    states = {(0, 1)}
    for i in range(1, 16):
        nxt = set()
        for h, q_value in states:
            shift = bs[i] - h
            for h_next in range(h + increments[i]):
                accel = increments[i] + h - h_next
                assert accel >= 1
                nxt.add((h_next, 3 * q_value + (1 << shift)))
        states = nxt
    terminal = sorted(q_value for h, q_value in states if h == 1)
    assert len(terminal) == 108_950

    shift = 24
    mod16 = 3**16
    inv16 = pow(1 << (shift + 34), -1, mod16)
    rows = []
    for q_value in terminal:
        eta0 = ((1 << shift) + q_value) * inv16 % mod16
        if eta0 % 9 not in (0, 8):
            continue
        y16 = (1 << 34) * eta0 - 1 - GAP
        numerator = (1 << shift) * y16 - q_value
        assert numerator % mod16 == 0
        y0base = numerator // mod16
        valid = []
        for t in range(3):
            y0 = y0base + (1 << (shift + 34)) * t
            if y0 % 3 and (y0 + K0) % 3:
                valid.append((t, y0))
        assert len(valid) == 1
        t, y0 = valid[0]
        rows.append((q_value, eta0 + t * mod16, y0))
    assert len(rows) == 45_046
    assert rows[0][0] == DELETED_Q

    upper = sum(Fraction(2, (2 * n + 1) * 3 ** (2 * n + 1)) for n in range(7))
    upper += Fraction(1, 20 * 3**14)
    width = upper + Fraction(Z, 1 << 40)
    lower_bound = Fraction(K0) * (L - width) / width
    step = 3 * (1 << 58)
    cap_numerator = 48 * L * K0
    records = []
    for q_value, eta, y0 in rows:
        k_hi = (cap_numerator - 1 - 29 * y0) // (29 * step)
        numerator = lower_bound.numerator - lower_bound.denominator * y0
        k_lo = 0 if numerator < 0 else numerator // (lower_bound.denominator * step) + 1
        records.append((q_value, eta, y0, k_lo, k_hi))
    assert records[0][3:5] == (28_812, 36_180)
    return records[1:]


class MaxProfile:
    """Piecewise exact maximum x on one 2-adic residue cylinder."""

    __slots__ = ("starts", "ends", "max_constants")

    def __init__(self, records, precision):
        modulus = 1 << precision
        inverse = pow(MOD17, -1, modulus)
        events = []
        segment_id = 0
        for _q_value, eta, _y0, k_lo, k_hi in records:
            length = k_hi - k_lo + 1
            assert 0 < length < modulus
            a = eta * inverse % modulus
            start = (a + k_lo) % modulus
            first_length = min(length, modulus - start)
            pieces = [(start, start + first_length, eta + MOD17 * (k_lo - start))]
            if first_length < length:
                pieces.append((0, length - first_length, eta + MOD17 * (k_lo + first_length)))
            for left, right, constant in pieces:
                assert 0 <= left < right <= modulus
                events.append((left, 1, segment_id, constant))
                events.append((right, -1, segment_id, constant))
                segment_id += 1

        events.sort(key=lambda item: (item[0], item[1]))
        active = [False] * segment_id
        heap = []
        starts = []
        ends = []
        max_constants = []
        pos_index = 0
        while pos_index < len(events):
            position = events[pos_index][0]
            while pos_index < len(events) and events[pos_index][0] == position:
                _position, kind, sid, constant = events[pos_index]
                if kind < 0:
                    active[sid] = False
                else:
                    active[sid] = True
                    heapq.heappush(heap, (-constant, sid))
                pos_index += 1
            while heap and not active[heap[0][1]]:
                heapq.heappop(heap)
            next_position = events[pos_index][0] if pos_index < len(events) else modulus
            if heap and position < next_position:
                starts.append(position)
                ends.append(next_position)
                max_constants.append(-heap[0][0])
        self.starts = starts
        self.ends = ends
        self.max_constants = max_constants

    def maximum(self, residue_s):
        index = bisect.bisect_right(self.starts, residue_s) - 1
        if index < 0 or residue_s >= self.ends[index]:
            return None
        return MOD17 * residue_s + self.max_constants[index]


class CandidateOracle:
    def __init__(self, records):
        self.records = records
        self.profiles = {}
        self.global_max = max(eta + MOD17 * k_hi for _q, eta, _y0, _lo, k_hi in records)

    def maximum(self, precision, residue_x):
        # Every small cylinder is nonempty in the deliberately retained superset;
        # using the global maximum is conservative until intervals become shorter
        # than their modulus at precision 13.
        if precision < 13:
            modulus = 1 << precision
            return residue_x + modulus * ((self.global_max - residue_x) // modulus)
        profile = self.profiles.get(precision)
        if profile is None:
            profile = MaxProfile(self.records, precision)
            self.profiles[precision] = profile
        modulus = 1 << precision
        residue_s = residue_x * pow(MOD17, -1, modulus) % modulus
        return profile.maximum(residue_s)


def explore(horizon):
    records = reconstruct_records()
    oracle = CandidateOracle(records)
    # i, height, precision, x residue, affine A, affine B, lower live x
    stack = [(16, 1, 0, 0, 1 << 34, -1 - GAP, 0)]
    counters = Counter()
    floor_phase = Counter()
    max_precision = 0
    unresolved = []

    while stack:
        i, height, precision, residue_x, affine_a, affine_b, lower_x = stack.pop()
        counters["processed_states"] += 1
        max_precision = max(max_precision, precision)
        modulus = 1 << precision
        max_x = oracle.maximum(precision, residue_x)
        if max_x is None or max_x < lower_x:
            counters["empty_states"] += 1
            continue

        # On a fixed valuation cylinder y_i is strictly increasing in x.
        max_t = (max_x - residue_x) // modulus
        assert residue_x + modulus * max_t == max_x
        assert affine_a > 0
        blue_t = (BLUE_FLOOR - 1 - affine_b) // affine_a
        blue_x = residue_x + modulus * blue_t
        if blue_x >= lower_x:
            lower_x = blue_x + 1
            if max_x < lower_x:
                counters["blue_states"] += 1
                floor_phase[i] += 1
                continue
            counters["partially_blue_states"] += 1

        if i > horizon:
            counters["unresolved_states"] += 1
            if len(unresolved) < 20:
                max_y = affine_a * max_t + affine_b
                unresolved.append((i, precision, residue_x, lower_x, max_x, max_y))
            continue

        numerator_b = 3 * affine_b + 1
        valuation_a = v2(affine_a)
        valuation_b = v2(numerator_b)

        if i <= 51:
            increment = b(i + 1) - b(i)
            max_accel = increment + height
            if min(valuation_a, valuation_b) > max_accel:
                counters["height_failure_states"] += 1
                continue

        if valuation_b < valuation_a:
            accel = valuation_b
            if i <= 51 and accel > max_accel:
                counters["height_failure_states"] += 1
                continue
            denominator = 1 << accel
            assert affine_a % denominator == 0 and numerator_b % denominator == 0
            new_height = increment + height - accel if i <= 51 else height
            stack.append(
                (i + 1, new_height, precision, residue_x,
                 3 * affine_a // denominator, numerator_b // denominator, lower_x)
            )
            counters["fixed_valuation_states"] += 1
        else:
            stack.append(
                (i, height, precision + 1, residue_x,
                 2 * affine_a, affine_b, lower_x)
            )
            stack.append(
                (i, height, precision + 1, residue_x + modulus,
                 2 * affine_a, affine_a + affine_b, lower_x)
            )
            counters["split_states"] += 1

    return {
        "status": "PASS" if not unresolved else "INCOMPLETE",
        "horizon": horizon,
        "blue_floor_exclusive": BLUE_FLOOR,
        "prefixes_in_superset": len(records),
        "global_x_max": oracle.global_max,
        "max_2adic_precision": max_precision,
        "profile_precisions": sorted(oracle.profiles),
        "counters": dict(sorted(counters.items())),
        "blue_state_phase_counts": {str(k): v for k, v in sorted(floor_phase.items())},
        "unresolved_examples": unresolved,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--horizon", type=int, default=260)
    args = parser.parse_args()
    print(json.dumps(explore(args.horizon), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
