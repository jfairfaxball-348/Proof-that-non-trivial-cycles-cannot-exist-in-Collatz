#!/usr/bin/env python3
"""NOT PROMOTED: bounded exact certified-blue/RL217 lattice experiment.

This is exploratory evidence, not a theorem about untested backward depths.

The script reconstructs the authoritative RL217 prefix progressions without
enumerating their 139,581,280 phase-51 survivors.  It then enumerates the exact
legal backward tree of the shortcut Collatz map from the certified seed 1, but
only along branches which can still enter the global RL217 y_0 interval by the
requested finite horizon.  Exact endpoints are intersected with whole prefix
lattices by their unique residue modulo 3*2^58.  The inherited terminal-Hensel
and phase-51 tests are applied only after an exact lattice equality is found.

For the shortcut map

    T(n) = n/2 (n even), (3*n+1)/2 (n odd),

the inverse edges used here are D(y)=2*y and O(y)=(2*y-1)/3 when y=2 mod 3.
The edge O(2)=1 is omitted only to cut the trivial 1 <-> 2 cycle; this does not
remove any distinct positive endpoint which reaches 1.
"""

import argparse
import hashlib
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path


A = 217_976_794_617
L = 137_528_045_312
P = 65_470_613_321
Z = L - P
K0 = 1 << 37
DELETED_Q = 43_013_953
MOD17 = 3**17
GAP = 3**16 * 2**13
STEP = 3 * (1 << 58)
HEIGHT_HORIZON = 51
AUTHORITATIVE_RL217_SURVIVORS = 139_581_280
DEFAULT_BACKWARD_HORIZON = 86
REPORT_HORIZONS = (75, 76, 80, 81, 83, 84, 85, 86)


def b(i):
    return A * i // L


def v2(n):
    n = abs(n)
    return (n & -n).bit_length() - 1


def reconstruct_records():
    """Reconstruct the exact RL217 incoming prefix/lattice records.

    This is the same RL212/RL215 reconstruction used by the promoted RL217
    verifier.  The returned list excludes RL216's already-deleted minimum-Q
    prefix and includes the inherited terminal-Hensel exceptional k values.
    """

    bs = [b(i) for i in range(17)]
    assert bs == [0, 1, 3, 4, 6, 7, 9, 11, 12, 14, 15, 17, 19, 20, 22, 23, 25]
    increments = [bs[i + 1] - bs[i] for i in range(16)]
    states = {(0, 1)}
    for i in range(1, 16):
        nxt = set()
        for height, q_value in states:
            shift = bs[i] - height
            for next_height in range(height + increments[i]):
                accel = increments[i] + height - next_height
                assert accel >= 1
                nxt.add((next_height, 3 * q_value + (1 << shift)))
        states = nxt
    terminal = sorted(q_value for height, q_value in states if height == 1)
    assert len(terminal) == 108_950

    shift = 24
    mod16 = 3**16
    inverse16 = pow(1 << (shift + 34), -1, mod16)
    rows = []
    for q_value in terminal:
        eta0 = ((1 << shift) + q_value) * inverse16 % mod16
        if eta0 % 9 not in (0, 8):
            continue
        y16 = (1 << 34) * eta0 - 1 - GAP
        numerator = (1 << shift) * y16 - q_value
        assert numerator % mod16 == 0
        y0base = numerator // mod16
        valid = []
        for lift in range(3):
            y0 = y0base + (1 << (shift + 34)) * lift
            if y0 % 3 and (y0 + K0) % 3:
                valid.append((lift, y0))
        assert len(valid) == 1
        lift, y0 = valid[0]
        rows.append((q_value, eta0 + lift * mod16, y0))
    assert len(rows) == 45_046
    assert rows[0][0] == DELETED_Q

    upper = sum(Fraction(2, (2 * n + 1) * 3 ** (2 * n + 1)) for n in range(7))
    upper += Fraction(1, 20 * 3**14)
    width = upper + Fraction(Z, 1 << 40)
    lower_bound = Fraction(K0) * (L - width) / width
    cap_numerator = 48 * L * K0

    modulus22 = 1 << 22
    forbidden = pow(pow(3, 34, modulus22), -1, modulus22)
    terminal_residues = (forbidden, (forbidden - 21) % modulus22)
    inverse_n22 = pow(MOD17, -1, modulus22)

    records = []
    for q_value, eta, y0 in rows:
        k_hi = (cap_numerator - 1 - 29 * y0) // (29 * STEP)
        numerator = lower_bound.numerator - lower_bound.denominator * y0
        k_lo = 0 if numerator < 0 else numerator // (lower_bound.denominator * STEP) + 1
        bad = set()
        for residue in terminal_residues:
            k = (residue - eta) * inverse_n22 % modulus22
            if k_lo <= k <= k_hi:
                bad.add(k)
        records.append((q_value, eta, y0, k_lo, k_hi, tuple(sorted(bad))))

    assert records[0][3:5] == (28_812, 36_180)
    assert records[0][5] == ()
    retained = records[1:]
    assert len(retained) == 45_045
    assert len({y0 % STEP for _q, _eta, y0, _lo, _hi, _bad in retained}) == 45_045
    assert all(y0 & 1 for _q, _eta, y0, _lo, _hi, _bad in retained)
    assert max(k_hi - k_lo + 1 for _q, _eta, _y0, k_lo, k_hi, _bad in retained) < (1 << 13)
    return retained


def survives_phase51(eta, k):
    """Exact direct membership test for RL217's universal phase-51 selector."""

    x = eta + MOD17 * k
    y = (1 << 34) * x - 1 - GAP
    height = 1
    for i in range(16, HEIGHT_HORIZON + 1):
        increment = b(i + 1) - b(i)
        accel = v2(3 * y + 1)
        if accel > increment + height:
            return False
        height = increment + height - accel
        y = (3 * y + 1) // (1 << accel)
    return True


def shortcut_steps_to_one(n, cap):
    for step in range(cap + 1):
        if n == 1:
            return step
        n = n // 2 if not (n & 1) else (3 * n + 1) // 2
    return None


def reachable_thresholds(y_min, y_max, horizon):
    """Safe exact pruning bounds for a remaining backward depth.

    Every inverse edge is at most D(y)=2y.  Also every inverse edge is at
    least f(y)=(2y-1)/3, whether or not O is legal.  Since

        f^r(y) = 1 + (2/3)^r (y-1),

    a node outside these bounds cannot enter [y_min,y_max] within the remaining
    depth.  The bounds are deliberately conservative with respect to legality.
    """

    lower = []
    upper = []
    for depth in range(horizon + 1):
        remaining = horizon - depth
        lower.append((y_min + (1 << remaining) - 1) >> remaining)
        upper.append(1 + ((y_max - 1) * 3**remaining >> remaining))
    return lower, upper


def run_experiment(horizon):
    assert horizon >= max(REPORT_HORIZONS)
    records = reconstruct_records()
    window_lengths = [k_hi - k_lo + 1 for _q, _eta, _y0, k_lo, k_hi, _bad in records]
    pre_hensel_points = sum(window_lengths)
    terminal_hensel_exclusions = sum(len(bad) for _q, _eta, _y0, _lo, _hi, bad in records)
    assert min(window_lengths) == 7_368
    assert max(window_lengths) == 7_369
    assert pre_hensel_points == 331_928_086
    assert terminal_hensel_exclusions == 170
    assert pre_hensel_points - terminal_hensel_exclusions == 331_927_916
    residue_index = {
        y0 % STEP: (q_value, eta, y0, k_lo, k_hi, bad)
        for q_value, eta, y0, k_lo, k_hi, bad in records
    }

    y_min = min(y0 + STEP * k_lo for _q, _eta, y0, k_lo, _hi, _bad in records)
    y_max = max(y0 + STEP * k_hi for _q, _eta, y0, _lo, k_hi, _bad in records)
    assert y_min == 24_913_843_852_126_965_674_543
    assert y_max == 31_285_589_992_896_666_338_783

    lower, upper = reachable_thresholds(y_min, y_max, horizon)
    frontier = [1]
    frontier_counts = {0: 1}
    exact_blue_by_depth = Counter()
    odd_blue_by_depth = Counter()
    lattice_matches = []
    digest = hashlib.sha256()

    for depth in range(1, horizon + 1):
        lo = lower[depth]
        hi = upper[depth]
        nxt = []
        for value in frontier:
            even_predecessor = value << 1
            if lo <= even_predecessor <= hi:
                nxt.append(even_predecessor)
            if value % 3 == 2:
                odd_predecessor = (2 * value - 1) // 3
                if odd_predecessor != 1 and lo <= odd_predecessor <= hi:
                    nxt.append(odd_predecessor)
        # D is injective with even output; O is injective with odd output.  Their
        # images are disjoint, so no set/deduplication or candidate enumeration is
        # hidden here.
        frontier = nxt
        frontier_counts[depth] = len(frontier)

        for value in frontier:
            if not (y_min <= value <= y_max):
                continue
            exact_blue_by_depth[depth] += 1
            if not (value & 1):
                continue
            odd_blue_by_depth[depth] += 1
            digest.update(f"{depth},{value}\n".encode())
            assert shortcut_steps_to_one(value, depth) == depth

            record = residue_index.get(value % STEP)
            if record is None:
                continue
            q_value, eta, y0, k_lo, k_hi, bad = record
            delta = value - y0
            assert delta % STEP == 0
            k = delta // STEP
            if not (k_lo <= k <= k_hi):
                continue
            lattice_matches.append(
                {
                    "depth": depth,
                    "value": value,
                    "Q": q_value,
                    "eta": eta,
                    "k": k,
                    "terminal_hensel_survivor": k not in bad,
                    "phase51_survivor": k not in bad and survives_phase51(eta, k),
                }
            )

    terminal_matches = [row for row in lattice_matches if row["terminal_hensel_survivor"]]
    phase51_matches = [row for row in terminal_matches if row["phase51_survivor"]]
    assert not lattice_matches
    assert not terminal_matches
    assert not phase51_matches

    cumulative_all = 0
    cumulative_odd = 0
    horizon_summary = {}
    for depth in range(1, horizon + 1):
        cumulative_all += exact_blue_by_depth[depth]
        cumulative_odd += odd_blue_by_depth[depth]
        if depth in REPORT_HORIZONS:
            horizon_summary[str(depth)] = {
                "exact_blue_endpoints_in_global_y0_interval": cumulative_all,
                "odd_exact_blue_endpoints_relevant_to_y0": cumulative_odd,
                "exact_prefix_lattice_matches": sum(row["depth"] <= depth for row in lattice_matches),
                "phase51_candidate_matches": sum(row["depth"] <= depth for row in phase51_matches),
            }

    return {
        "status": "PASS",
        "classification": "bounded exact computation; NOT PROMOTED",
        "certified_seed": 1,
        "shortcut_backward_horizon_inclusive": horizon,
        "global_y0_interval": [y_min, y_max],
        "rl217_prefixes_tested_by_lattice_index": len(records),
        "rl217_prefix_window_points_before_terminal_hensel": pre_hensel_points,
        "terminal_hensel_exclusions_in_retained_prefixes": terminal_hensel_exclusions,
        "rl217_points_after_terminal_hensel_before_phase51": pre_hensel_points
        - terminal_hensel_exclusions,
        "rl217_candidate_enumeration_performed": False,
        "prefix_residues_mod_3_times_2pow58_unique": True,
        "prefix_k_window_length_range": [min(window_lengths), max(window_lengths)],
        "maximum_prefix_k_window_length_less_than_2pow13": True,
        "frontier_size_at_horizon_after_exact_safe_pruning": frontier_counts[horizon],
        "maximum_pruned_frontier_size": max(frontier_counts.values()),
        "frontier_size_by_depth_70_through_horizon": {
            str(depth): frontier_counts[depth] for depth in range(70, horizon + 1)
        },
        "new_odd_blue_endpoints_by_depth": {
            str(depth): odd_blue_by_depth[depth]
            for depth in sorted(odd_blue_by_depth)
            if odd_blue_by_depth[depth]
        },
        "horizon_summary": horizon_summary,
        "odd_blue_endpoint_digest_sha256": digest.hexdigest(),
        "exact_prefix_lattice_matches_before_terminal_hensel": len(lattice_matches),
        "exact_matches_after_terminal_hensel": len(terminal_matches),
        "exact_matches_after_phase51": len(phase51_matches),
        "rl217_candidates_certified_blue_by_this_bounded_test": len(phase51_matches),
        "rl217_candidates_uncovered_by_this_bounded_test": AUTHORITATIVE_RL217_SURVIVORS
        - len(phase51_matches),
        "uncovered_set": "all authoritative RL217 phase-51 survivors (unchanged)",
        "finite_horizon_lock": (
            "No claim is made for legal backward words of shortcut length greater than the tested horizon."
        ),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--horizon", type=int, default=DEFAULT_BACKWARD_HORIZON)
    parser.add_argument("--expected", type=Path)
    args = parser.parse_args()
    result = run_experiment(args.horizon)
    if args.expected is not None:
        assert json.loads(args.expected.read_text()) == result
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
