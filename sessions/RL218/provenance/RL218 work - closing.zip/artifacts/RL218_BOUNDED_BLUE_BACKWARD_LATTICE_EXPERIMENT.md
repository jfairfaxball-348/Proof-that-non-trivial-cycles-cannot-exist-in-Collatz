# RL218 scratch result — bounded exact blue-backward/RL217 lattice test

Status: **NOT PROMOTED**. Classification: **bounded exact computational
evidence**. This note makes no claim about backward words longer than the
tested horizon and does not alter the RL217 proof state.

## 1. Scope and exact comparison interface

The symbolic word algebra is recorded separately in
`RL218_BACKWARD_WORD_ALGEBRA.md`. For the raw shortcut inverse letters

\[
D(Y)=2Y,\qquad O(Y)=(2Y-1)/3\quad(Y=2\pmod 3),
\]

a fixed legal word applied to a fixed certified seed gives one exact integer,
not a residue class of certified integers. If its output is `Y`, equality with
one RL217 prefix family is exactly

\[
Y=y_*+3\,2^{58}k.                                      \tag{1}
\]

Thus the first aggregate selector is `Y=y_* (mod 3*2^58)`, followed by the
finite `k` interval. Exact reconstruction gives:

- 45,045 retained RL217 prefixes;
- 45,045 distinct prefix residues `y_* mod 3*2^58`;
- `k`-window lengths exactly 7,368 or 7,369;
- 331,928,086 window points before the 170 terminal-Hensel exclusions;
- 331,927,916 points after terminal Hensel and before the RL217 phase-51
  consumer.

Consequently every exact blue endpoint can be tested against all prefixes by
one residue-table lookup and, because the prefix residues are distinct, can
match at most one prefix. No candidate population scan is involved.

If an exact `(prefix,k)` equality is found, the phase-51 cylinder
`x=R (mod 2^m)` is tested as

\[
k=(R-\eta)(3^{17})^{-1}\pmod {2^m}.                    \tag{2}
\]

The promoted live-cylinder depths satisfy `13<=m<=25`. Since every prefix
window has length below `2^13`, each individual phase cylinder contains at
most one `k` in any fixed prefix. This is important: after RL217, a fixed-seed
blue-word equality is necessarily a singleton test inside a prefix, even
though the same residue machinery can aggregate the test across all prefixes.

## 2. Exact bounded backward search

The experiment uses the exactly certified seed `1` and generates every
distinct positive endpoint in its legal shortcut backward tree through raw
word length 86. The edge `O(2)=1` is omitted only to cut the trivial `1<->2`
cycle. This does not omit any distinct positive integer reaching `1`.

Only branches capable of entering the complete retained-prefix root interval

\[
[24,913,843,852,126,965,674,543,
 31,285,589,992,896,666,338,783]                       \tag{3}
\]

by depth 86 are retained. The pruning is exact. With `r` backward steps left,
every inverse edge is at most `2Y`, while every inverse edge is at least
`f(Y)=(2Y-1)/3`; moreover

\[
f^r(Y)=1+(2/3)^r(Y-1).
\]

Therefore a node is discarded only if even all doublings remain below (3), or
if even the relaxed all-`f` lower envelope remains above (3). Legality is not
relaxed when endpoints are generated.

All RL roots in this interface are odd, so even blue endpoints in (3) cannot
match a candidate. The exact cumulative results are:

| Raw-word horizon | All blue endpoints in (3) | Odd relevant endpoints | Exact prefix-lattice matches | Phase-51 matches |
|---:|---:|---:|---:|---:|
| 75 | 0 | 0 | 0 | 0 |
| 76 | 35 | 1 | 0 | 0 |
| 80 | 37 | 1 | 0 | 0 |
| 81 | 27,076 | 1,381 | 0 | 0 |
| 83 | 27,076 | 1,381 | 0 | 0 |
| 84 | 573,436 | 43,210 | 0 | 0 |
| 85 | 573,436 | 43,210 | 0 | 0 |
| 86 | 577,574 | 43,370 | 0 | 0 |

The 43,370 odd endpoints have SHA-256 digest

`6de0cd2a2f6af2b8059744aa603e347c4c1f359c8c1a15a102296e6b53932a4a`

under canonical lines `depth,value\n`. Each was independently replayed
forward and reached `1` in exactly its recorded depth.

The exact zero occurs before terminal Hensel and before the phase-51 selector:
none of the 43,370 endpoints is congruent to any retained `y_*` modulo
`3*2^58` with its quotient in the prefix window. Hence the broader
331,928,086-point pre-Hensel lattice already has zero hits, and a fortiori the
authoritative phase-51 family has zero hits.

## 3. Proof-state consequence and uncovered set

This bounded experiment certifies **zero** new RL217 candidates blue. The
uncovered set is exactly the entire authoritative phase-51 survivor interface,
unchanged:

\[
\boxed{139,581,280\text{ arithmetic candidates across }45,045\text{ prefixes}.}
\]

This is not evidence that those candidates are non-blue. It says only that no
candidate is one of the exact backward endpoints from seed `1` having shortcut
distance at most 86.

No prefix, H21 state, mod-18 class, eta class, terminal rank or physical object
is deleted by this experiment.

## 4. Modern route barrier indicated by the test

The exact RL coverage stayed at zero at every tested horizon even as the odd
blue endpoint set in the target interval jumped from 1 to 43,370. Meanwhile,
after exact safe interval pruning, the active reverse frontier still peaked at
3,162,437 nodes at depth 84. Mere depth growth is therefore already expensive
while producing only singleton equality probes against the post-RL217 prefix
windows.

This is a **method barrier**, not an intrinsic no-go theorem. It reinforces the
symbolic quantifier barrier:

- one fixed blue seed plus one fixed word certifies one exact endpoint;
- word legality or a congruence match alone does not certify the varying
  endpoint progression blue;
- after phase 51, each prefix cylinder already samples at most one `k`;
- continuing raw backward depth would be progressively closer to generating
  individual blue points, not to proving a whole candidate progression blue.

A materially stronger continuation would need a compressed certificate for a
whole endpoint interval/progression pulled back through the algebra, or a
forward affine/cylinder argument which maps whole candidate pieces into an
independently certified blue set. It should not infer coverage from residue
abundance or proximity.

## 5. Reproduction

From the repository root:

```sh
python3 .rl-work/RL218/artifacts/verify_bounded_blue_backward_lattice.py \
  --horizon 86 \
  --expected .rl-work/RL218/artifacts/verify_bounded_blue_backward_lattice_output.json
```

Observed result: `PASS`; wall time was about 20 seconds on the local shell
worker. The script reconstructs the prefix lattices and generates backward
endpoints, but never enumerates the 139,581,280 authoritative candidates.
