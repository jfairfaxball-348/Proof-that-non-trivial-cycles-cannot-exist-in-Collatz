#!/usr/bin/env python3
"""Portable candidate verifier for RL218 backward-word algebra and LTE screen.

This verifier packages the already-established RL218 scratch checks.  It does
not modify proof state and does not claim anything outside the finite domains
reported in its JSON result.
"""

import argparse
import hashlib
import json
from collections import Counter
from itertools import product
from pathlib import Path


RAW_WORD_LENGTH_DOMAIN = (0, 8)
RAW_SEED_DOMAIN = (1, 128)
GROUPED_ODD_COUNT_DOMAIN = (1, 5)
GROUPED_EXPONENT_DOMAIN = (1, 4)
GROUPED_SEED_DOMAIN = (1, 99)

A = 217_976_794_617
L = 137_528_045_312
K0 = 1 << 37

EXPECTED_ROW_DIGEST = (
    "24a57291eaf8685ff84f8e2ebe02b751a5597b84a86d4d9140d2f3bfb7b4dd90"
)
EXPECTED_SCREEN_DIGEST = (
    "bca5aecb93b3b4c1d9c64e42fac6b37452b64409d401008d202d2559710b57e2"
)
EXPECTED_VALUATION_DISTRIBUTION = Counter(
    {
        2: 8458,
        3: 8458,
        4: 8458,
        5: 6768,
        6: 5078,
        7: 3388,
        8: 2098,
        9: 1208,
        10: 637,
        11: 304,
        12: 128,
        13: 46,
        14: 13,
        15: 4,
    }
)


def v2(n):
    """Return the 2-adic valuation of a nonzero integer."""

    assert n != 0
    n = abs(n)
    return (n & -n).bit_length() - 1


def direct_word(seed, word):
    """Return (legal, output) for D:Y->2Y and O:Y->(2Y-1)/3."""

    value = seed
    for letter in word:
        if letter == "D":
            value *= 2
        else:
            assert letter == "O"
            if value % 3 != 2:
                return False, None
            value = (2 * value - 1) // 3
            assert value > 0 and value % 2 == 1
    return True, value


def raw_normal_form(word):
    """Return (n,h,c) for the formal value W(s)=(2^n*s-c)/3^h."""

    constant = 0
    odd_count = 0
    for letter in word:
        if letter == "D":
            constant *= 2
        else:
            assert letter == "O"
            constant = 2 * constant + 3**odd_count
            odd_count += 1
    return len(word), odd_count, constant


def verify_raw_words():
    checks = 0
    words = 0
    for length in range(RAW_WORD_LENGTH_DOMAIN[0], RAW_WORD_LENGTH_DOMAIN[1] + 1):
        for word in product(("D", "O"), repeat=length):
            words += 1
            exponent, odd_count, constant = raw_normal_form(word)
            for seed in range(RAW_SEED_DOMAIN[0], RAW_SEED_DOMAIN[1] + 1):
                legal, output = direct_word(seed, word)
                divisible = (
                    (2**exponent * seed - constant) % (3**odd_count) == 0
                )
                assert legal == divisible
                if legal:
                    assert output == (
                        (2**exponent * seed - constant) // (3**odd_count)
                    )
                checks += 1
    assert words == 511
    assert checks == 65_408
    return words, checks


def grouped_q(exponents):
    value = 0
    for index, exponent in enumerate(exponents, start=1):
        value = 2**exponent * value + 3 ** (index - 1)
    return value


def verify_grouped_words():
    checks = 0
    exponent_words = 0
    for odd_count in range(
        GROUPED_ODD_COUNT_DOMAIN[0], GROUPED_ODD_COUNT_DOMAIN[1] + 1
    ):
        for exponents in product(
            range(GROUPED_EXPONENT_DOMAIN[0], GROUPED_EXPONENT_DOMAIN[1] + 1),
            repeat=odd_count,
        ):
            exponent_words += 1
            word = []
            for exponent in exponents:
                word.extend("D" for _ in range(exponent - 1))
                word.append("O")
            word = tuple(word)
            total_exponent = sum(exponents)
            q_value = grouped_q(exponents)
            raw_exponent, raw_odd_count, raw_constant = raw_normal_form(word)
            assert (raw_exponent, raw_odd_count, raw_constant) == (
                total_exponent,
                odd_count,
                q_value,
            )
            expanded_q = sum(
                3 ** (index - 1) * 2 ** sum(exponents[index:])
                for index in range(1, odd_count + 1)
            )
            assert expanded_q == q_value
            for seed in range(
                GROUPED_SEED_DOMAIN[0], GROUPED_SEED_DOMAIN[1] + 1
            ):
                legal, output = direct_word(seed, word)
                assert legal == (
                    (2**total_exponent * seed - q_value) % (3**odd_count)
                    == 0
                )
                if legal:
                    assert output == (
                        (2**total_exponent * seed - q_value) // (3**odd_count)
                    )
                    odd_seed = seed >> v2(seed)
                    canonical_exponent = total_exponent + v2(seed)
                    assert (
                        v2(3**odd_count * output + q_value)
                        == canonical_exponent
                    )
                    assert (
                        (3**odd_count * output + q_value)
                        // 2**canonical_exponent
                        == odd_seed
                    )
                checks += 1
    assert exponent_words == 1_364
    assert checks == 135_036
    return exponent_words, checks


def b(index):
    return A * index // L


def reconstruct_prefix_bases():
    """Reconstruct all 45,046 inherited bases used by the LTE screen."""

    breakpoints = [b(index) for index in range(17)]
    increments = [breakpoints[index + 1] - breakpoints[index] for index in range(16)]
    states = {(0, 1)}
    for index in range(1, 16):
        next_states = set()
        for height, q_value in states:
            shift = breakpoints[index] - height
            for next_height in range(height + increments[index]):
                next_states.add((next_height, 3 * q_value + (1 << shift)))
        states = next_states

    terminal = sorted(q_value for height, q_value in states if height == 1)
    assert len(terminal) == 108_950

    shift = 24
    mod16 = 3**16
    gap = mod16 * 2**13
    inverse16 = pow(1 << (shift + 34), -1, mod16)
    rows = []
    for q_value in terminal:
        eta0 = ((1 << shift) + q_value) * inverse16 % mod16
        if eta0 % 9 not in (0, 8):
            continue
        y16 = (1 << 34) * eta0 - 1 - gap
        numerator = (1 << shift) * y16 - q_value
        assert numerator % mod16 == 0
        y0base = numerator // mod16
        lifts = []
        for lift in range(3):
            y0 = y0base + (1 << (shift + 34)) * lift
            if y0 % 3 and (y0 + K0) % 3:
                lifts.append((eta0 + lift * mod16, y0))
        assert len(lifts) == 1
        eta, y0 = lifts[0]
        rows.append((q_value, eta, y0))

    assert len(rows) == 45_046
    assert all(y0 > 0 and y0 % 2 == 1 and y0 % 3 == 2 for _, _, y0 in rows)
    digest = hashlib.sha256()
    for q_value, eta, y0 in rows:
        digest.update(f"{q_value},{eta},{y0}\n".encode())
    assert digest.hexdigest() == EXPECTED_ROW_DIGEST
    return rows, digest.hexdigest()


def verify_lte_screen(rows):
    valuation_distribution = Counter()
    surviving_bases = []
    digest = hashlib.sha256()
    for index, (q_value, eta, y0) in enumerate(rows):
        odd_depth = v2(y0 + 1)
        valuation_distribution[odd_depth] += 1
        assert 1 <= odd_depth < 58
        base_power_candidate = 3**odd_depth * ((y0 + 1) >> odd_depth) - 1
        modulus = 1 << (58 - odd_depth)
        residue = base_power_candidate % modulus
        digest.update(f"{q_value},{odd_depth},{residue}\n".encode())
        if residue == 0:
            surviving_bases.append((index, q_value, eta, y0, odd_depth))

    assert valuation_distribution == EXPECTED_VALUATION_DISTRIBUTION
    assert surviving_bases == []
    assert digest.hexdigest() == EXPECTED_SCREEN_DIGEST
    return valuation_distribution, digest.hexdigest(), surviving_bases


def run_verifier():
    raw_words, raw_checks = verify_raw_words()
    grouped_words, grouped_checks = verify_grouped_words()
    rows, row_digest = reconstruct_prefix_bases()
    valuation_distribution, screen_digest, surviving_bases = verify_lte_screen(rows)
    return {
        "status": "PASS",
        "classification": (
            "candidate verification of analytic identities and an exact finite "
            "LTE-comb screen; NOT PROMOTED"
        ),
        "raw_word_exhaustive_domain": {
            "alphabet": ["D", "O"],
            "word_length_inclusive": list(RAW_WORD_LENGTH_DOMAIN),
            "seeds_inclusive": list(RAW_SEED_DOMAIN),
            "words_tested": raw_words,
            "word_seed_checks": raw_checks,
            "properties_checked": [
                "raw affine normal form",
                "terminal divisibility iff sequential legality",
                "legal output equality",
            ],
        },
        "grouped_word_exhaustive_domain": {
            "odd_inverse_count_inclusive": list(GROUPED_ODD_COUNT_DOMAIN),
            "each_exponent_inclusive": list(GROUPED_EXPONENT_DOMAIN),
            "seeds_inclusive": list(GROUPED_SEED_DOMAIN),
            "exponent_words_tested": grouped_words,
            "word_seed_checks": grouped_checks,
            "properties_checked": [
                "grouped Q recurrence equals expanded formula",
                "grouped form equals raw form",
                "terminal divisibility iff sequential legality",
                "canonical valuation and odd-core recovery",
            ],
        },
        "lte_comb_finite_screen": {
            "inherited_prefix_bases_reconstructed": len(rows),
            "includes_rl216_deleted_minimum_q_base": True,
            "all_reconstructed_bases_screened": True,
            "v2_y0_plus_1_distribution": {
                str(key): valuation_distribution[key]
                for key in sorted(valuation_distribution)
            },
            "prefix_row_digest_sha256": row_digest,
            "screen_record_format": "Q,j,screen_residue\\n",
            "screen_digest_sha256": screen_digest,
            "necessary_mod_2pow58_screen_survivors": len(surviving_bases),
            "scope_lock": (
                "The zero-survivor result concerns only the explicit RL80 LTE "
                "comb and does not cover the full certified basin."
            ),
        },
        "proof_state_mutation_performed": False,
    }


def main():
    default_expected = Path(__file__).with_name(
        "verify_rl218_backward_word_and_lte_screen_output.json"
    )
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected", type=Path, default=default_expected)
    parser.add_argument("--no-expected", action="store_true")
    args = parser.parse_args()

    result = run_verifier()
    if not args.no_expected:
        expected = json.loads(args.expected.read_text())
        assert expected == result
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
