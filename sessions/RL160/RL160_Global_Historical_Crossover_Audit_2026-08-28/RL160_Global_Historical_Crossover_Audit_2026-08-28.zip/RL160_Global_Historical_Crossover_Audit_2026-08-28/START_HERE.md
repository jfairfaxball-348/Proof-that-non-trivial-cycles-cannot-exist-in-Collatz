# RL160 — Global Historical Crossover Audit

**Session:** RL160  
**Date:** 2026-08-28  
**Status:** **CLOSED — PRODUCTIVE NEGATIVE AUDIT / BARRIER SYNTHESIS**  
**Promotion tag:** `RL160-GLOBAL-HISTORICAL-CROSSOVER-NEGATIVE-AUDIT-2026-08-28`

## What this session did
RL160 deliberately stepped out of the narrow RL158–RL159 elimination thread and audited the inherited proof corpus for theorem-level crossovers: old exact identities that might become stronger when combined with the later dyadic/valuation/reconstruction machinery.

The audit did **not** prove that non-trivial Collatz cycles are impossible. It did produce two exact barrier theorems, consolidate the RL158–RL159 same-root obstruction, and reduce the live search to crossovers that contain genuinely nonlocal, ownership-sensitive information.

## Promoted exact conclusions
1. **Fixed-radius joint-factorization barrier.** If each local observable factors through the residue class `u mod 2^r`, then their joint observable also factors through `u mod 2^r`. Stacking such coordinates cannot manufacture an independent finite-radius discriminator.
2. **Ordered-valuation barrier.** The valuation multiset does not determine chronological affine closure data. The words `(1,2)` and `(2,1)` have the same multiset and total valuation but yield `(9x+5)/8` and `(9x+7)/8` respectively.
3. **Same-root elimination remains non-discriminating.** RL158/RL159 already showed that polynomial/resultant/Sylvester/SNF information evaluated only at the distinguished physical root can reconstruct tautological relations rather than independent cycle restrictions.

## What remains live
The surviving route is an **ownership-sensitive global bridge**: combine singleton/full-phase ownership with a genuinely nonlocal invariant such as weighted-difference/perimeter, population/packing, signed defect, chronological phase/order data, positive lift/rescaling, or exact cycle closure/divisibility.

See `RL160_EXACT_SYNTHESIS_REPORT.md` for the proof and `RL160_SESSION_STATE_AND_RL161_KICKOFF_2026-08-28.md` for the authoritative handover.
