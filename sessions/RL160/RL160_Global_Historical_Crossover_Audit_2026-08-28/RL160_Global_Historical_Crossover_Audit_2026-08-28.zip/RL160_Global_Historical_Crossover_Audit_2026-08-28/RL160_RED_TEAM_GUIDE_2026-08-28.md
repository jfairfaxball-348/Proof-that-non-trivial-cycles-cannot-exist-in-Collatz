# RL160 Red-Team Guide

A reviewer should try to break RL160 at the following points.

## A. Fixed-radius theorem
- Check that every observable claimed to collapse is explicitly assumed to factor through the *same* `π_r`.
- Do not generalize the theorem to observables carrying unbounded radius, physical magnitude, order, or ownership information.
- Confirm the conclusion is only “no independent discriminator from coordinate stacking,” not “no dyadic method can ever work.”

## B. Ordered-valuation certificate
- Recompute `T_b(T_a(x))=(9x+3+2^a)/2^(a+b)`.
- Verify `(1,2)` gives `(9x+5)/8` and `(2,1)` gives `(9x+7)/8`.
- Verify the two words have identical valuation multiset and total valuation.
- Confirm this proves insufficiency of unordered data, not impossibility of an order-sensitive valuation theorem.

## C. Same-root barrier
- Keep this as inherited RL158/RL159 method-barrier information.
- Do not promote it into a universal impossibility theorem for elimination methods.

## D. Global status
- Search for any sentence claiming all non-trivial cycles are excluded; such a sentence would be an error.
- Check that every surviving proposed route contains ownership, chronology, population/packing, or a whole-orbit identity beyond a single fixed-radius residue state.

## E. Deterministic replay
From the fresh package run:

```bash
python RL160_CERTIFICATES/order_sensitive_affine_composition.py
python verify_rl160_report.py .
```

Both commands must exit zero.
