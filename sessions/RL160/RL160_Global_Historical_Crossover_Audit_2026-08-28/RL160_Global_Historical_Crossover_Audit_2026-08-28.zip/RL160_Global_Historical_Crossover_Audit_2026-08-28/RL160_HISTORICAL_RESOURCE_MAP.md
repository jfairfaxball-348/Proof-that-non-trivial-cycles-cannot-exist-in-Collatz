# RL160 Historical Resource Map

## Audit policy
RL160 used the frozen proof-state ledgers and global-audit sessions as compression layers. Historical sessions were not recursively re-proved unless a candidate crossover needed an exact dependency. This follows the repository verification-economy rule.

## Resource families examined

| Historical family | Exact resource contributed | RL160 use | Audit disposition |
|---|---|---|---|
| Early cycle closure/product/divisibility work | Nonlocal identities tied to a complete periodic orbit | Candidate global target | **LIVE** if coupled to ownership |
| Dyadic residue, endpoint, suffix and no-carry work | Finite-radius local coordinates | Tested for coordinate stacking | **DEAD AS AN INDEPENDENT CROSSOVER** at fixed radius |
| RL72 global audit / lemma catalogue / route map | Consolidated theorem inventory, barriers and open gates | Strategic baseline | Compression layer; no historical re-audit required |
| Weighted-difference / perimeter and population / packing work | Global sums, counts, packing pressure | Candidate bridge from local ownership to global contradiction | **LIVE** |
| Blue/dyadic branch sieve + valuation reconstruction | Large exact branch exclusions plus warning that a branch-to-global theorem is still required | Tested against later reconstruction | **CONDITIONAL**; remains a sieve without a global bridge |
| Ownership / inverse-tree / singleton and full-phase work | Non-homogeneous information about which physical residue/branch is actually occupied | Current missing ingredient | **LIVE / PRIORITY** |
| Valuation reconstruction and full-residue recovery work | Local valuation data can recover the finite dyadic state | Tested against older local coordinates and global closure | **LOCAL COMPLETENESS CONFIRMED; NOT GLOBAL BY ITSELF** |
| RL158 one-binomial resultant route | Exact algebraic elimination at the physical root | Candidate crossover with older polynomial relations | **DEAD AS DISCRIMINATOR** |
| RL159 joint distinguished-root Sylvester/SNF route | Exact multi-relation elimination/SNF reconstruction | Candidate stronger algebraic crossover | **DEAD AS DISCRIMINATOR** |

## Crossover taxonomy
A candidate can survive RL160 only if it contributes information not already measurable from a single fixed-radius residue class and not erased by replacing the chronological valuation word by an unordered statistic.

That leaves four useful categories:

- **ownership:** which physical branch/residue is occupied, with a non-homogeneous condition tied to a cycle's least or otherwise distinguished element;
- **chronology/order:** information sensitive to the order of valuation exponents, not merely their histogram or sum;
- **population/packing:** information coupling many orbit locations simultaneously;
- **global closure:** an identity quantified over the whole orbit, such as exact divisibility/product, weighted differences, or a signed global defect.

Any proposed RL161+ crossover should identify explicitly which of those nonlocal resources it adds.
