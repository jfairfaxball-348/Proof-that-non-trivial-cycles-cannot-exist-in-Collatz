#!/usr/bin/env python3
"""Fast deterministic verifier for an unpacked RL160 report directory."""
import subprocess, sys
from pathlib import Path

root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required=[
 'START_HERE.md','RL160_HISTORICAL_RESOURCE_MAP.md','RL160_CROSSOVER_CANDIDATES.md',
 'RL160_EXACT_SYNTHESIS_REPORT.md','RL160_CERTIFIED_FACTS_AND_PROOF_LEDGER.md',
 'RL160_RED_TEAM_GUIDE_2026-08-28.md','RL160_SESSION_STATE_AND_RL161_KICKOFF_2026-08-28.md',
 'RL161_OWNERSHIP_WEIGHTED_GLOBAL_BRIDGE_TARGET.md','RL160_FRESH_UNPACK_REVIEW.md',
 'RL160_CERTIFICATES/order_sensitive_affine_composition.py',
 'RL160_CERTIFICATES/ORDER_SENSITIVE_AFFINE_COMPOSITION_CERTIFICATE.txt'
]
for p in required:
    if not (root/p).is_file():
        raise SystemExit(f'MISSING {p}')
state=(root/'RL160_SESSION_STATE_AND_RL161_KICKOFF_2026-08-28.md').read_text()
assert 'Global proof status' in state and '**OPEN.**' in state
report=(root/'RL160_EXACT_SYNTHESIS_REPORT.md').read_text()
assert 'No finite-cycle contradiction has been obtained.' in report
r=subprocess.run([sys.executable,str(root/'RL160_CERTIFICATES/order_sensitive_affine_composition.py')],text=True,capture_output=True)
if r.returncode:
    print(r.stdout); print(r.stderr,file=sys.stderr); raise SystemExit(r.returncode)
assert 'RL160-B PASS' in r.stdout
print('RL160 REPORT VERIFIER PASS')
print(r.stdout.strip())
