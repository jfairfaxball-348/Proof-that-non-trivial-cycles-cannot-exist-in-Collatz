# RL160 Crossover Candidates

## Decision matrix

| Candidate crossover | Exact question | RL160 result | Status after RL160 |
|---|---|---|---|
| Endpoint fractions + suffix residues + dyadic branch labels | Do several local coordinate systems jointly distinguish more than the full residue modulo `2^r`? | No. If all factor through the same `π_r`, their product factors through `π_r`. | **ELIMINATED** |
| No-carry coordinates + valuation reconstruction | Can reconstruction reverse the old projection-blindness barrier? | Only locally. Reconstruction can make the residue state complete, but cannot distinguish two integers in the same `π_r` fibre or impose a global orbit condition by itself. | **ELIMINATED IN PURELY LOCAL FORM** |
| Valuation counts/multiset + cycle closure | Does knowing all local valuation multiplicities determine the affine closure numerator? | No. `(1,2)` and `(2,1)` give different affine intercepts despite identical multiset and total valuation. | **ELIMINATED** |
| Old polynomial identities + RL158/RL159 elimination | Do multiple same-root algebraic relations become independent through resultants/SNF? | Not in the inherited construction: the physical root relation can reconstruct a tautology. | **ELIMINATED AS CURRENT DISCRIMINATOR** |
| Blue/dyadic branch sieve + valuation reconstruction | Does exact local reconstruction turn a large blue sieve into a proof that every possible cycle branch is caught? | Not without a branch-to-global/ownership theorem. | **CONDITIONAL / NOT CLOSED** |
| Singleton/full-phase ownership + weighted-difference/perimeter | Can occupying a distinguished physical branch force a quantitative global imbalance? | No theorem found in RL160; this uses genuinely independent information. | **LIVE — HIGH PRIORITY** |
| Ownership + population/packing | Can each owned phase force enough mutually incompatible global packing demand? | No theorem found in RL160; exact counting framework is plausible. | **LIVE — HIGH PRIORITY** |
| Ownership + signed defect / positive lift | Can sign/positivity plus a distinguished physical representative force a contradiction? | Exact coupling not present in inherited ledger. | **LIVE** |
| Ordered valuation word + exact cycle closure | Can chronological information, rather than a histogram, interact with global divisibility/product constraints? | Not eliminated by RL160. | **LIVE** |

## Promotion decision
The RL160 target explicitly permitted promotion either for a genuinely new exact crossover **or for a complete negative audit that formally eliminates the major crossover possibilities and sharply narrows the live route**.

RL160 satisfies the second gate. Three broad shortcut classes are now excluded from future promotion claims unless genuinely new information is added:

1. stacking finite-radius observables that all factor through the same residue state;
2. replacing chronological valuation data by counts, a multiset, or only the total valuation;
3. adding further same-distinguished-root polynomial elimination/SNF relations without an independence theorem.

The live route is correspondingly narrowed to ownership-sensitive, chronological, population-level, or whole-orbit constraints.
