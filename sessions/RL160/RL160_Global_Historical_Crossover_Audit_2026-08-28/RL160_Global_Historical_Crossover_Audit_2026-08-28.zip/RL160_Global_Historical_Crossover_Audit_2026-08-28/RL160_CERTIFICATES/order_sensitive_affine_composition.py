#!/usr/bin/env python3
"""Exact deterministic certificate for RL160-B."""
from collections import Counter
from fractions import Fraction


def compose(word):
    """Return (A,B,S) with composed map (A*x+B)/2**S."""
    A, B, S = 1, 0, 0
    for a in word:
        if not isinstance(a, int) or a < 1:
            raise ValueError("valuation exponents must be positive integers")
        A, B = 3 * A, 3 * B + (1 << S)
        S += a
    return A, B, S


def apply(triple, x):
    A, B, S = triple
    return Fraction(A*x+B, 1 << S)


def main():
    w12=(1,2)
    w21=(2,1)
    c12=compose(w12)
    c21=compose(w21)
    assert Counter(w12)==Counter(w21)==Counter({1:1,2:1})
    assert sum(w12)==sum(w21)==3
    assert c12==(9,5,3), c12
    assert c21==(9,7,3), c21
    assert c12 != c21
    for x in (1,3,5,17):
        def T(y,a): return (3*y+1)/Fraction(1<<a)
        assert apply(c12,x)==T(T(Fraction(x),1),2)
        assert apply(c21,x)==T(T(Fraction(x),2),1)
    print("RL160-B PASS")
    print("word (1,2): (9*x+5)/8")
    print("word (2,1): (9*x+7)/8")
    print("same multiset and total valuation; different affine intercept")

if __name__=='__main__':
    main()
