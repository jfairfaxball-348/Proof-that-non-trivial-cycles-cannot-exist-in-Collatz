# RL170 fresh-unpack review

Verify the outer sidecar, unpack to a new directory, verify `SHA256SUMS.txt`,
and run `python3 verify_rl170_report.py .`.
