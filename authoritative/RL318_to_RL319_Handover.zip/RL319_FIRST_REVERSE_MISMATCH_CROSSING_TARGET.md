# RL319 — first reverse-mismatch crossing target

Date prepared: 2026-09-14
Status: PREPARED, NOT STARTED
Source Git blob of authoritative target: `e555c7de3c8926d57ca6fe8b5fc4fc9bc93a50c8`

Work from RL318's exact nonzero-residue setting.

Let `P` be the physical content-`h` state and `S` the primitive shadow state.
At the first sign crossing,
- `delta=P-S>0`;
- physical is even;
- shadow is odd;
- `delta'=(delta-2S-h)/2<0`;
- `0<delta<2S+h`.

Required attack:
1. derive a stronger exact non-homogeneous relation or congruence at this reverse mismatch;
2. combine it, if possible, with `gcd(h,E)=1`, `gcd(h,6)=1`, boundary states, and the
   exact first-mismatch clock;
3. if no contradiction follows, isolate the exact necessary crossing condition and freeze it
   as the next frontier.

Do not claim completion from positivity or heuristic gcd/density arguments.
