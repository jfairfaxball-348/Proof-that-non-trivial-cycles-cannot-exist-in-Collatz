# RL318 -> RL319 transport state

RL318: CLOSED AND FROZEN.
RL319: PREPARED, NOT STARTED.

Frozen source:
`sessions/RL318/RL318_SESSION_STATE_AND_RL319_KICKOFF.md`
Git blob:
`bd28a5fe207abe282ca1cf7e1ffbaa1e6937db8b`

RL319 primary task: work directly at the first reverse mismatch forced by RL318.
Do not restart broad historical archaeology, standalone homogeneous `T_h` invariants,
support-by-support grammar, or already exhausted bounded scans.

Primary success modes:
- contradiction forcing `h=1`, zero gap, or impossible divisibility/coprimality;
- an exact bounded carry independent of support;
- a non-homogeneous relation joining the crossing to the boundary data;
- otherwise a clean no-go plus a strictly sharper necessary condition for any survivor.

Secondary branch, only after a clean crossing no-go: `epsilon=0` ordered-row branch with
genuine `D0` ownership and inherited nonnegative-defect geometry.

Scope remains open: Gate A, Gate B, and global exclusion are not proved.
