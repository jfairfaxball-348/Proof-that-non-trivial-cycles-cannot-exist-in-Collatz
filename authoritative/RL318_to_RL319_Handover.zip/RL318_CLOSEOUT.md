# RL318 transport closeout mirror

Date: 2026-09-14
Status: CLOSED AND FROZEN
Source of record: `sessions/RL318/RL318_CLOSEOUT.md`
Source Git blob: `92dbd63e777e64ef850b9319c0129a6973916e84`

This transport mirror does not replace the frozen source file. It records the theorem-grade
frontier required to start RL319.

RL318 keeps two distinct reduced frontiers:
- internal-only: `ell>=190537`;
- conditional on the external `R>=2^71` certificate: `ell>=49,547,666,544`.

For the RL317 nonzero-residue branch let
`H=2^a+3^ell`, `d=gcd(H,epsilon)`, `h=H/d>1`, `E=epsilon/d`.
The physical content-`h` row and coprime-content shadow row have gap
`delta=P-S` with
`delta_0=E>0` and `delta_a=-E<0`.
At every phase `h|P` and `gcd(S,h)=1`, hence `delta!=0`.

Same-parity updates preserve the sign:
- even/even: `delta' = delta/2`;
- odd/odd: `delta' = 3 delta/2`.

The inherited first mismatch occurs at `t=v_2(E)=v_2(epsilon)` with orientation
physical odd / shadow even and satisfies
`delta' = P + (delta+h)/2 > 0`.
It therefore cannot be the sign crossing.

Consequently a later first crossing exists and must have orientation
physical even / shadow odd. At that step
`delta'=(delta-2S-h)/2<0`, so
`0<delta<2S+h`.

Gate A remains OPEN. Gate B remains OPEN. Global positive non-trivial-cycle exclusion
remains OPEN. No Collatz-conjecture claim is made.
