#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
required = {
    "RL318_CLOSEOUT.md": [
        "Status: CLOSED AND FROZEN",
        "delta_0=E>0",
        "delta_a=-E<0",
        "physical even / shadow odd",
        "0<delta<2S+h",
    ],
    "RL318_PROOF_LEDGER.md": [
        "gcd(h,E)=1",
        "gcd(h,6)=1",
        "t=v_2(E)=v_2(epsilon)",
        "delta_{k+1}=(delta_k-2S_k-h)/2",
    ],
    "RL318_SESSION_STATE_AND_RL319_KICKOFF.md": [
        "RL318: CLOSED AND FROZEN",
        "RL319: PREPARED, NOT STARTED",
    ],
    "RL319_FIRST_REVERSE_MISMATCH_CROSSING_TARGET.md": [
        "Status: PREPARED, NOT STARTED",
        "first reverse-mismatch",
        "gcd(h,E)=1",
    ],
}
for name, needles in required.items():
    text = (root / name).read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            raise SystemExit(f"missing required marker {needle!r} in {name}")
print("RL318->RL319 portable handover verifier: PASS")
