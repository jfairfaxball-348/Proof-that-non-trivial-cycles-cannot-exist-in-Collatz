# RL318 transport proof ledger mirror

Status: frozen theorem-grade handover mirror.
Source of record: `sessions/RL318/RL318_PROOF_LEDGER.md`
Source Git blob: `a4c151daba7f58a1d1513ee1b9d0efaf24f39a5e`

## Inherited exact data

`H=X+Y`, `X=2^a`, `Y=3^ell`,
`d=gcd(H,epsilon)`, `h=H/d`, `E=epsilon/d`,
`gcd(h,E)=1`, `h>1`, `gcd(h,6)=1`.

The physical row has states divisible by `h`; the primitive shadow row has states coprime
to `h`. The row boundary gaps are `+E` and `-E`.

## RL318 theorem-grade consequences

1. Gap nonvanishing:
   `delta_j=P_j-S_j` is never zero because `h|P_j` and `gcd(S_j,h)=1`.

2. Crossing necessity:
   since `delta_0=E>0`, `delta_a=-E<0`, and zero is impossible, there is a first
   `k` with `delta_k>0` and `delta_{k+1}<0`.

3. Same-parity steps cannot cross:
   even/even gives `delta_{j+1}=delta_j/2`;
   odd/odd gives `delta_{j+1}=3delta_j/2`.

4. The first parity mismatch occurs exactly at
   `t=v_2(E)=v_2(epsilon)` and has orientation physical odd / shadow even.

5. That first mismatch cannot cross because
   `delta_{t+1}=P_t+(delta_t+h)/2>0`.

6. Hence the first sign crossing is a later reverse mismatch:
   physical even / shadow odd.

7. Reverse-mismatch formula:
   `delta_{k+1}=(delta_k-2S_k-h)/2`.

8. First-crossing inequality:
   `0<delta_k<2S_k+h`.

## Barrier

The inequality still contains the variable shadow state `S_k` and by itself does not
compress to a contradiction in `h,E,t`. RL319 must preserve the additive `+h` term and
seek a genuinely non-homogeneous crossing consequence.
