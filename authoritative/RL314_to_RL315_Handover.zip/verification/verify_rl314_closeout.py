#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
state = (root / "RL314_SESSION_STATE_AND_RL315_KICKOFF.md").read_text(encoding="utf-8")
target = (root / "RL315_TARGET_SUMMARY.md").read_text(encoding="utf-8")

assert "Completed RL: RL314" in state
assert "Incoming RL: RL315" in state
assert "PREPARED, NOT STARTED" in state
assert "proper gcd-block levels cannot all be distinct" in state
assert "g<=h+1" in target
assert "full-D ownership forces `E_j=E_k`" in target
print("RL314 closeout handover verifier: PASS")
