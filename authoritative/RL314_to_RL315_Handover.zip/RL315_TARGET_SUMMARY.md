# RL315 target summary

Start from RL311 in the `lambda<3` sector:

- `A=ga`, `L=g ell`, `gcd(a,ell)=1`;
- proper gcd-block levels satisfy `0<=E_j<=h`;
- exhaustive RL311 alternative: `g<=h+1` OR a short genuine full-D owned balanced return.

Primary target: in the controlled branch `g<=h+1`, prove that full-D ownership forces `E_j=E_k` for some `j<k`.

Success removes the controlled branch and makes the balanced-return mechanism exhaustive in the one-sided sector.

Required independent resource: genuinely ownership-sensitive full-D/integer/quotient/order information, not recurrence geometry alone.
