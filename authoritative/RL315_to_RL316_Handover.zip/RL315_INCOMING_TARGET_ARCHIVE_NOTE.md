# Archived incoming RL315 target

The exact incoming target is preserved by Git blob identity from
`authoritative/RL315_CONTROLLED_MULTIPLICITY_FULL_D_REPEATED_LEVEL_TARGET.md`
at RL315 entry.

Original blob SHA:
`9504714b0579e753d302c5d9b011c1b1e65d45a3`.

See repository history at incoming HEAD
`3bad9e4df6f70472fdf1230b2ac951434391f3d2` for byte-exact content.
