# RL223 bounded finite-state residue probe

**Status: NOT PROMOTED. Scratch research only.**

## Exact scope

The probe uses only the current authoritative constants

- `N=A-24=217976794593`,
- `M=L-16=137528045296`,
- `N-M=80448749297`,

and the tail-numerator recurrence for a binary word `d_0,...,d_(N-1)`:

`Q_(j+1)=Q_j` for `d_j=0`, and
`Q_(j+1)=3Q_j+2^j` for `d_j=1`.

It treats **every** binary word of length `N` and exact weight `M` as attainable.
It does not encode candidate-specific parity/2-adic legality from fixed `y16`,
an H21 continuation automaton, phase/state/incidence/charge constraints,
terminal-Hensel or phase-51 continuation cylinders, positivity/minimum-orbit
conditions, or a physical full cycle. Therefore none of the results below is a
legal-H21 selector, candidate deletion, branch contradiction, or Gate result.

The only actually certified H21-side data used are the fixed totals `(N,M)`, the
affine recurrence, and (for target replay) the current arithmetic witness
coordinates. No additional legal-continuation constraint is claimed to be
represented.

## Gap-free bounded computation

For every eligible modulus

`5 <= q <= 1023`, `q` odd, `gcd(q,6)=1`,

the forward DP exhausts `(prefix length, exact prefix weight, Q mod q)`. There
are 340 such moduli. For every one, it finds a fixed-weight prefix slice whose
reachable numerator set is exactly `Z/qZ`:

- all 340 / 340 tested moduli saturated;
- no unsaturated modulus in the declared interval;
- the largest minimal saturating prefix length was 16;
- selected prefix weights were at most 9 and selected prefix zero counts at
  most 11.

Appending the same suffix

`1^(M-r) 0^((N-M)-(h-r))`

to every word in a saturating `(h,r)` prefix slice preserves the exact total
length and weight. Concatenation gives

`Q(prefix || suffix) = 3^(M-r) Q(prefix) + 2^h Q(suffix) (mod q)`.

Because `3^(M-r)` is a unit, the complete unconstrained `(N,M)` word set also
attains every residue modulo every tested `q`. Its endpoint residues are also
all of `Z/qZ` because `2^N` is a unit.

## Authoritative witness replay

The current witness values

`y0=24921895945404894117887`,
`y16=63944214675001842327551`

were projected independently to

`T=2^N y0-3^M y16 (mod q)`.

For all 340 tested moduli, the verifier constructs a compressed unconstrained
word `prefix || 1^remaining_ones 0^remaining_zeros` with `Q=T mod q`, and checks
that the resulting endpoint is `y0 mod q`. Thus the witness target intersects
the unconstrained word-side set for every tested modulus. This is not a physical
continuation witness.

Selected exact replay rows:

| q | minimal `(h,r)` | `T mod q` | constructed prefix |
|---:|:---:|---:|:---|
| 5 | (5,2) | 3 | `01001` |
| 7 | (5,3) | 6 | `11001` |
| 11 | (7,2) | 7 | `0011000` |
| 25 | (8,4) | 8 | `01001011` |
| 97 | (11,5) | 14 | `11000001101` |
| 511 | (14,6) | 55 | `10111100000001` |
| 1009 | (15,7) | 558 | `000101011000111` |
| 1019 | (16,6) | 341 | `0000101000101011` |
| 1021 | (15,8) | 832 | `100011001101011` |

## Analytic block-switch blindness lemma

The bounded observation has a general elementary explanation for the same
unconstrained relaxation. Let

`a=4*3^(-1) mod q`, `t=ord_q(a)`, and `k=q*t`.

Build a prefix from `k` two-bit blocks, choosing each block as either `10` or
`01`. Every such prefix has length `2k` and weight `k`. If block `i` is switched
from `10` to `01`, its numerator changes by

`c_i=4^i 3^(k-1-i)`.

Since `c_(i+t)=c_i mod q`, the `q` indices
`0,t,...,(q-1)t` have one equal unit increment. Switching `s=0,...,q-1` of
these blocks yields all residues modulo `q`. Appending a common fixed-count
suffix preserves surjectivity whenever

`q*ord_q(4*3^(-1)) <= min(M,N-M)`.

Euler's theorem gives `ord_q(...) <= phi(q) <= q-1`. Here

`min(M,N-M)=80448749297`,

and the largest integer `Q` with `Q(Q-1)` at most this capacity is `283635`:

- `283635*283634 = 80448529590 <= 80448749297`;
- `283636*283635 = 80449096860 > 80448749297`.

Consequently, for **every** `q <= 283635` with `gcd(q,6)=1`, fixed length and
fixed odd count alone leave the unconstrained tail-numerator and endpoint sets
equal to all of `Z/qZ`. This is an exact relaxation-blindness lemma, not a claim
about legal H21 continuations.

## Strongest observation and missing datum

An odd modulus is not selective when fed only `(N,M)` and the affine numerator
recurrence: both the exhaustive range `q<=1023` and the analytic block-switch
lemma show full residue surjectivity for a large exact range. A viable RL223
selector must therefore couple the odd-modulus state to independently certified
legal-continuation data. The current authoritative handover does not expose such
a tail automaton or candidate-to-tail-cylinder map in the reduced interface.

## Reproduction and verifier

Run from the repository root:

```sh
python3 .rl-work/RL223/finite_state_probe/generate_probe.py \
  --max-modulus 1023 --max-prefix-length 128 \
  --output .rl-work/RL223/finite_state_probe/probe_certificate.json

python3 .rl-work/RL223/finite_state_probe/verify_probe.py \
  .rl-work/RL223/finite_state_probe/probe_certificate.json \
  --output .rl-work/RL223/finite_state_probe/verification_output.json
```

Expected terminal summary:

`PASS q=5..1023 eligible=340 surjective=340 max_minimal_h=16 scope=UNCONSTRAINED_BINARY_WORDS_ONLY`

Verifier output SHA256:

`25469bd4132ffedd68f58a18cc95caee2c72a4bfc2d7188f70a551058c7914c1`

## Uncovered ranges

- Direct DP for `q>1023`: **NOT TESTED / NOT PROMOTED**.
- The uniform analytic bound for `q>283635`: not asserted; the sharper
  per-modulus capacity condition may still hold, but was not catalogued.
- Any actual legal H21 continuation residue set: **NOT COMPUTED / NOT PROMOTED**.
- Candidate, prefix, state, eta-class, terminal-rank, Gate, or branch effects:
  **0 claimed**.
