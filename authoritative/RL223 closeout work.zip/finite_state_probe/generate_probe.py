#!/usr/bin/env python3
"""Bounded exact RL223 probe for unconstrained fixed-weight binary tails.

This is scratch research, NOT PROMOTED.  It intentionally does not model legal
H21 continuations.  It models all binary words of a fixed length and odd count
under the affine numerator recurrence

    Q_{j+1} = Q_j                    if d_j = 0,
    Q_{j+1} = 3 Q_j + 2^j           if d_j = 1.

For a short prefix of length h and weight r, the script searches for exact
surjectivity modulo every q in a bounded range with gcd(q, 6) = 1.  Short-prefix
surjectivity extends constructively to the authoritative huge (N, M) because a
common suffix can supply all remaining zeros and ones.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Dict, List, Tuple


A = 217_976_794_617
L = 137_528_045_312
N = A - 24
M = L - 16
ZEROS = N - M

AUTHORITATIVE_WITNESS = {
    "Q16": 43_079_489,
    "eta": 3_722_043_165_201,
    "k": 28_821,
    "state": "011",
    "y0": 24_921_895_945_404_894_117_887,
    "y16": 63_944_214_675_001_842_327_551,
}


def word_numerator_mod(word: str, q: int) -> int:
    """Evaluate Q modulo q, with word[0] the earliest tail bit d_0."""
    value = 0
    two_power = 1 % q
    for bit in word:
        if bit == "1":
            value = (3 * value + two_power) % q
        elif bit != "0":
            raise ValueError(f"non-binary symbol {bit!r}")
        two_power = (2 * two_power) % q
    return value


def fixed_weight_reachable(q: int, h: int) -> List[Dict[int, str]]:
    """Return residue -> lexicographically first discovered word by weight."""
    by_weight: List[Dict[int, str]] = [{0: ""}]
    two_power = 1 % q
    for _position in range(h):
        next_by_weight: List[Dict[int, str]] = [dict() for _ in range(len(by_weight) + 1)]
        for weight, residues in enumerate(by_weight):
            for residue in sorted(residues):
                word = residues[residue]
                next_by_weight[weight].setdefault(residue, word + "0")
                odd_residue = (3 * residue + two_power) % q
                next_by_weight[weight + 1].setdefault(odd_residue, word + "1")
        by_weight = next_by_weight
        two_power = (2 * two_power) % q
    return by_weight


def first_surjective_slice(q: int, max_prefix_length: int) -> Tuple[int, int, Dict[int, str]] | None:
    """Find the least h, then least r, with S(q,h,r) equal to all Z/qZ."""
    by_weight: List[Dict[int, str]] = [{0: ""}]
    two_power = 1 % q
    for h in range(1, max_prefix_length + 1):
        next_by_weight: List[Dict[int, str]] = [dict() for _ in range(len(by_weight) + 1)]
        for weight, residues in enumerate(by_weight):
            for residue in sorted(residues):
                word = residues[residue]
                next_by_weight[weight].setdefault(residue, word + "0")
                odd_residue = (3 * residue + two_power) % q
                next_by_weight[weight + 1].setdefault(odd_residue, word + "1")
        by_weight = next_by_weight
        two_power = (2 * two_power) % q
        for weight, residues in enumerate(by_weight):
            if len(residues) == q:
                return h, weight, residues
    return None


def compressed_suffix_numerator_mod(ones: int, q: int) -> int:
    """Q for 1^ones 0^zeros modulo q; trailing zeros do not alter Q."""
    return (pow(3, ones, q) - pow(2, ones, q)) % q


def uniform_block_switch_bound() -> int:
    """Largest Q with q(q-1) <= min(M, N-M) for every q <= Q."""
    capacity = min(M, ZEROS)
    q = (1 + math.isqrt(1 + 4 * capacity)) // 2
    while (q + 1) * q <= capacity:
        q += 1
    while q * (q - 1) > capacity:
        q -= 1
    return q


def extension_for_target(
    q: int,
    h: int,
    weight: int,
    witnesses: Dict[int, str],
    target: int,
) -> dict:
    """Construct prefix + 1^s 0^z attaining target in the relaxation."""
    remaining_ones = M - weight
    remaining_zeros = (N - M) - (h - weight)
    if remaining_ones < 0 or remaining_zeros < 0:
        raise AssertionError("authoritative (N,M) cannot accommodate prefix slice")
    suffix_q = compressed_suffix_numerator_mod(remaining_ones, q)
    shift = pow(2, h, q)
    odd_scale = pow(3, remaining_ones, q)
    needed_prefix_residue = ((target - shift * suffix_q) * pow(odd_scale, -1, q)) % q
    prefix_word = witnesses[needed_prefix_residue]
    achieved = (odd_scale * word_numerator_mod(prefix_word, q) + shift * suffix_q) % q
    if achieved != target:
        raise AssertionError("compressed extension failed")
    return {
        "prefix_word": prefix_word,
        "prefix_residue": needed_prefix_residue,
        "remaining_ones": remaining_ones,
        "remaining_zeros": remaining_zeros,
        "suffix_form": "1^remaining_ones 0^remaining_zeros",
        "suffix_numerator_mod_q": suffix_q,
        "achieved_tail_numerator_mod_q": achieved,
    }


def build_certificate(max_modulus: int, max_prefix_length: int) -> dict:
    tested_moduli = [q for q in range(5, max_modulus + 1, 2) if math.gcd(q, 6) == 1]
    modulus_results = []
    unsaturated = []
    for q in tested_moduli:
        found = first_surjective_slice(q, max_prefix_length)
        if found is None:
            unsaturated.append(q)
            modulus_results.append({"q": q, "status": "NOT_SATURATED_WITHIN_BOUND"})
            continue
        h, weight, witnesses = found
        canonical = "\n".join(f"{residue}:{witnesses[residue]}" for residue in range(q))
        target = (pow(2, N, q) * AUTHORITATIVE_WITNESS["y0"] - pow(3, M, q) * AUTHORITATIVE_WITNESS["y16"]) % q
        extension = extension_for_target(q, h, weight, witnesses, target)
        endpoint = (
            pow(pow(2, N, q), -1, q)
            * (pow(3, M, q) * AUTHORITATIVE_WITNESS["y16"] + target)
        ) % q
        if endpoint != AUTHORITATIVE_WITNESS["y0"] % q:
            raise AssertionError("target/endpoint identity failed")
        modulus_results.append(
            {
                "q": q,
                "status": "SURJECTIVE_UNCONSTRAINED_FIXED_WEIGHT_PREFIX",
                "minimal_prefix_length": h,
                "prefix_weight": weight,
                "reachable_count": len(witnesses),
                "witness_map_sha256": hashlib.sha256(canonical.encode("ascii")).hexdigest(),
                "authoritative_witness": {
                    "target_tail_numerator_mod_q": target,
                    "target_endpoint_mod_q": AUTHORITATIVE_WITNESS["y0"] % q,
                    "intersection_nonempty": True,
                    "construction": extension,
                },
            }
        )

    saturated = len(tested_moduli) - len(unsaturated)
    return {
        "format": "rl223-unconstrained-fixed-weight-residue-probe-v1",
        "promotion_status": "NOT PROMOTED",
        "scope": {
            "represented": [
                "all binary words of total length N",
                "exact total odd count M",
                "affine tail-numerator recurrence modulo q",
            ],
            "not_represented": [
                "candidate-specific parity/2-adic legality from fixed y16",
                "H21 phase/state/incidence/charge constraints after phase 16",
                "terminal-Hensel or phase-51 cylinder constraints on the continuation",
                "positivity/minimum-orbit/full physical cycle constraints",
            ],
            "consequence": "Surjectivity here is only a blindness result for an unconstrained relaxation, not for legal H21 continuations.",
        },
        "authoritative_parameters": {"A": A, "L": L, "N": N, "M": M, "zeros": ZEROS},
        "authoritative_witness": AUTHORITATIVE_WITNESS,
        "bounded_search": {
            "q_min": 5,
            "q_max": max_modulus,
            "q_conditions": "q odd and gcd(q,6)=1",
            "max_prefix_length": max_prefix_length,
            "tested_modulus_count": len(tested_moduli),
            "saturated_modulus_count": saturated,
            "unsaturated_moduli": unsaturated,
            "outside_q_range": "NOT PROMOTED / NOT TESTED",
            "prefix_lengths_above_bound": "NOT PROMOTED / NOT TESTED",
        },
        "extension_lemma": {
            "statement": "If fixed-weight prefixes (h,r) attain every residue modulo q, then fixed (N,M) words attain every residue whenever M>=r and N-M>=h-r.",
            "concatenation": "Q(prefix||suffix)=3^(M-r)Q(prefix)+2^h Q(suffix) (mod q)",
            "fixed_suffix": "suffix=1^(M-r)0^((N-M)-(h-r)), Q(suffix)=3^(M-r)-2^(M-r)",
            "unit_condition": "gcd(q,3)=1 makes multiplication by 3^(M-r) invertible",
        },
        "analytic_block_switch_lemma": {
            "promotion_status": "NOT PROMOTED",
            "scope": "unconstrained fixed-(N,M) binary words only",
            "statement": "For a=4*3^(-1) mod q and t=ord_q(a), k=q*t blocks chosen independently as 10 or 01 have fixed length 2k and weight k and attain every Q residue modulo q.",
            "coefficient_formula": "Q=sum_{i=0}^{k-1} 4^i*3^(k-1-i)*2^(epsilon_i), epsilon_i in {0,1}",
            "switch_increment": "Changing block i from 10 to 01 adds c_i=4^i*3^(k-1-i); c_(i+t)=c_i mod q.",
            "coverage": "There are q equal unit increments at i=0,t,...,(q-1)t; switching s=0,...,q-1 of them covers every residue.",
            "capacity_condition": "q*ord_q(4*3^(-1)) <= min(M,N-M)",
            "euler_uniform_bound_reason": "ord_q(4*3^(-1)) <= phi(q) <= q-1, so q(q-1) <= min(M,N-M) suffices.",
            "capacity": min(M, ZEROS),
            "uniform_q_upper_bound_inclusive": uniform_block_switch_bound(),
            "uniform_bound_product": uniform_block_switch_bound() * (uniform_block_switch_bound() - 1),
            "next_integer_product": (uniform_block_switch_bound() + 1) * uniform_block_switch_bound(),
            "conclusion": "For every q <= the uniform bound with gcd(q,6)=1, the unconstrained authoritative fixed-(N,M) tail-numerator and endpoint residue sets are all of Z/qZ.",
        },
        "moduli": modulus_results,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-modulus", type=int, default=255)
    parser.add_argument("--max-prefix-length", type=int, default=96)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.max_modulus < 5 or args.max_prefix_length < 1:
        parser.error("bounds must satisfy max-modulus>=5 and max-prefix-length>=1")
    certificate = build_certificate(args.max_modulus, args.max_prefix_length)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(certificate, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    search = certificate["bounded_search"]
    print(
        "generated",
        args.output,
        f"tested={search['tested_modulus_count']}",
        f"saturated={search['saturated_modulus_count']}",
        f"unsaturated={search['unsaturated_moduli']}",
    )


if __name__ == "__main__":
    main()
