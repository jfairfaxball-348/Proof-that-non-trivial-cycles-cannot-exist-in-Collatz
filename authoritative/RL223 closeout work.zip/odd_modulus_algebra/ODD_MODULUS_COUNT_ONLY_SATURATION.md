# RL223 odd-modulus algebra: exact count-only saturation

Status: scratch theorem note, **NOT PROMOTED**.  This note does not alter the
incoming authoritative state.

## 1. Conventions

Let `w=(w_0,...,w_(N-1))` be a binary parity word for the ordinary shortcut
Collatz map

`C(x)=x/2` if `x` is even, and `C(x)=(3x+1)/2` if `x` is odd.

Write `M=sum_j w_j`.  If the one positions are

`0 <= r_1 < ... < r_M < N`, then its affine numerator is

`Q(w)=sum_(i=1)^M 2^(r_i) 3^(M-i)`,                         (1)

and every realization satisfies

`2^N x_N = 3^M x_0 + Q(w)`.                                (2)

For an integer `q>=2` with `gcd(q,6)=1`, define the exact count-only word-side
set

`S_(N,M)(q)={Q(w) mod q : w in {0,1}^N, sum w_j=M}`.         (3)

This set represents only ordinary parity legality and the exact length/odd-count
constraints.  It does not represent the current exact start `y16`, the already
frozen phase-51 cylinders, a height-one/nonnegative-height condition, least-state
ownership, cyclic closure, or any other H21 restriction.

## 2. Exact characterization and parity legality

The set in (3) has either of the following gap-free recurrences (all operations
are modulo `q`):

`S_(0,0)={0}`, and `S_(n,m)=empty` outside `0<=m<=n`,

`S_(n,m)=2*S_(n-1,m) union (3^(m-1)+2*S_(n-1,m-1))`,        (4)

or, on splitting by the last bit,

`S_(n,m)=S_(n-1,m) union (3*S_(n-1,m-1)+2^(n-1))`.          (5)

Equations (1), (4), and (5) are exact algebraic characterizations, not upper
bounds.

Every binary word is an ordinary legal parity word for infinitely many positive
starts.  Indeed, (2) gives the unique starting cylinder

`x_0 = -3^(-M) Q(w) (mod 2^N)`.                             (6)

The usual induction on the first bit proves that every positive integer in this
cylinder follows `w`: modulo 2 the congruence forces `x_0` even when `w_0=0`
and odd when `w_0=1`; after applying the indicated first step, division of the
congruence by 2 gives the length-`N-1` cylinder for the suffix.

Since `gcd(q,2^N)=1`, CRT sharpens this statement.  For every word `w` and every
`a mod q`, there are infinitely many positive starts simultaneously realizing
`w` and satisfying `x_0=a mod q`.  Consequently the exact attainable joint
residue set is

`{(a,s,b): a in Z/q, s in S_(N,M)(q),`
`             b=2^(-N)(3^M*a+s) mod q}`.                   (7)

In particular, the endpoint projection `b` is all of `Z/q` even for any one
fixed word, if the odd-modulus starting residue is free.  With `a` fixed, the
endpoint set is the affine image

`2^(-N)(3^M*a+S_(N,M)(q))`.                                (8)

For one fixed exact integer start, however, there is exactly one legal word and
one endpoint.  Thus neither (7) nor the saturation theorem below may be applied
to the exact current `y16` without an additional argument preserving that start
and all H21 constraints.

## 3. Uniform saturation theorem

**Theorem (Euler-block saturation).**  Let `H=phi(q)`.  If

`min(M,N-M) >= q*H`,                                        (9)

then

`S_(N,M)(q)=Z/q`.                                           (10)

**Proof.**  Euler's theorem gives

`2^H=3^H=1 (mod q)`.                                        (11)

Use `q` consecutive length-`2H`, weight-`H` blocks, independently chosen as

`B0 = 1^H 0^H`,

`B1 = 1^(H-1) 0 1 0^(H-1)`.                                (12)

Both variants start with `1`.  Changing block `j`, indexed from zero, from
`B0` to `B1` moves that block's last one from global position
`R+2Hj+H-1` to `R+2Hj+H`, without crossing another one.  If the fixed filler
after the blocks has `F` ones, formula (1) gives the exact change

`delta_j = 2^(R+2Hj+H-1) 3^(F+(q-1-j)H)`.                  (13)

Every factor is a unit modulo `q`, and consecutive changes obey

`delta_(j+1)/delta_j = 2^(2H) 3^(-H) = 1 (mod q)`.          (14)

Thus all `q` switches add one common unit `delta`.  Switching exactly `t`
blocks gives `Q_base+t*delta` for `0<=t<=q`; the first `q` of these are all
residues modulo `q`.  Condition (9) leaves a filler with exactly
`M-qH` ones and `N-M-qH` zeros, so every word has the prescribed `(N,M)`.
Every constructed word is ordinarily legal for its own positive starting
cylinder by (6).  QED.

Since `H=phi(q)<=q-1`, the factorization-free sufficient condition is

`min(M,N-M) >= q*(q-1)`.                                   (15)

For the frozen RL223 tail dimensions,

`N=217976794593`, `M=137528045296`, `N-M=80448749297`.

Therefore (15) proves count-only saturation for every `q` coprime to 6 with

`2<=q<=283635`,                                             (16)

because

`283635*283634=80448529590 <= 80448749297`,

whereas `283636*283635=80449096860`.

This includes every small odd modulus that would normally be used for a finite
endpoint automaton.  It is an analytic saturation result; no enumeration over
the enormous tail length is involved.

**Fixed-prefix corollary.**  Let `p` be any fixed initial word of length `ell`
and weight `r`.  If the residual resources `M-r` and
`(N-ell)-(M-r)` are each at least `q*phi(q)`, the full
numerators of the formal count-only completions of `p` still fill `Z/q`.  Indeed,

`Q(pv)=3^(M-r)Q(p)+2^ell Q(v)`,

and the first term is fixed while the multiplier of `Q(v)` is a unit modulo
`q`.  Thus retaining any one frozen finite leading tail word (including a
phase-51 word) does not rescue a count-only odd-modulus selector once enough
ones and zeros remain.  The realizing starts still vary with `v`; this does not
assert that the completions continue the one exact current `y16`.

**Exact `q=5` witness after a legal phase-51 prefix.**  For the inherited common
witness, the exact 52-bit/35-one leading tail word is

`P=1111111111111001101111010011001010101111110110011000`.

Starting from

`y16=63944214675001842327551`,

direct shortcut iteration verifies every bit of `P` and ends at

`y51=710371286312677333954849`.  Put

`B0=11110000`, `B1=11101000`,

and append four selectable blocks, followed by

`1^137528045245 0^80448749264`.                              (16a)

This has the exact total tail length `N` and odd count `M`.  For block masks
where `1` means `B1`, exact modular composition gives

`mask 0011 -> Q=0`, `0001 -> 1`, `0000 -> 2`,
`1111 -> 3`, `0111 -> 4 (mod 5)`.                            (16b)

For the same tuple, `y0=24921895945404894117887` and direct reduction gives
`T=3 mod 5`, so mask `1111` is a formal count-only match.  Also `y16` is odd
directly from `y16=2^34*eta-1-3^16*2^13`; both selectable blocks begin in `1`.
This verifies the already-fixed phase-51 prefix and the next bit, but it does
**not** verify that any selectable block is the actual continuation of this
exact `y51`.

## 4. Relation to the RL222 target

For a legal tail from `y16` to `y_end`, (2) says

`Qtail=2^N*y_end-3^M*y16`.

The RL222 target is

`T(c)=2^N*y0-3^M*y16`.

Since `2` is a unit modulo `q`,

`Qtail=T(c) (mod q)  iff  y_end=y0 (mod q)`.                (17)

Thus the proposed tail-numerator coordinate is exactly an endpoint-return
congruence.  It is genuinely word-sensitive only if `y_end mod q` is computed
for the actual continuation attached to the exact candidate.  At the weaker
scope consisting of ordinary legality plus `(N,M)` alone, (10) makes the
word-side numerator set—and by (8) the endpoint set for a fixed starting
residue—surjective, so there is no candidate selector.

There is also an exact affine formula on every inherited `k`-lift.  From

`y0=y0_*+3*2^58*k`, `eta=eta_*+3^17*k`, and
`y16=2^34*eta-1-3^16*2^13`, one obtains

`T(k+1)-T(k)`
` = 2^N*(3*2^58)-3^M*(2^34*3^17)`
` = 3*2^34*(2^A-3^L)`
` = 3*2^34*D`.                                              (18)

Modulo `q`, the target image on complete `k` residue classes therefore has
exactly `q/gcd(D,q)` residues.  If `q|D`, the target coordinate is constant on
the affine lift.  If `gcd(D,q)=1`, it is a permutation of `k mod q`.  Neither
case overcomes the count-only word-side saturation.

## 5. Scope counterexamples and falsifiable next target

- Surjectivity is not unconditional at short lengths: for `q=5,N=2,M=1`,
  `S_(2,1)(5)={1,2}`.
- A fixed exact start does not admit all words: its parity continuation is
  deterministic.  Count-only saturation cannot be counted as a survivor or a
  deletion for any current arithmetic candidate.
- The blocks in (11) were not proved to preserve the frozen phase-51 cylinders,
  H21 height conditions, least-state ownership, or cyclic closure.  The theorem
  must not be silently promoted to any of those scopes.

The next falsifiable target is therefore:

> For at least one small `q`, compute `y_end(k) mod q` for the actual deterministic
> continuation of every frozen phase-51 cylinder/candidate, or prove an exact
> finite transition/recurrence that preserves the frozen H21 tail language.
> Compare it with `y0(k) mod q`.  A single surviving explicit tuple falsifies an
> asserted empty intersection.  An automaton that retains only `(remaining
> length, remaining odd count, Q mod q)` is already proved structurally blind by
> (10) and is not such a transition system.
