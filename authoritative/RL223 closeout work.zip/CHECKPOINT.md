# Local RL checkpoint (NOT AUTHORITATIVE)

- BASE_HEAD: `fe3edec580b7553bbda52ba1936f32fed488ae60`
- Current incoming RL: `RL223`
- Target: `authoritative/RL222_Full_Period_Quotient_Residue_Structural_Blindness_2026-09-01/RL223_FULL_TAIL_RETURN_DEFECT_ODD_MODULUS_ENDPOINT_COUPLING_TARGET.md`
- Last fully verified state: incoming verification passed.  At the count-only parity-word relaxation, the exact length-5/weight-2 gadget has `Q mod 5 = {0,1,2,3,4}`; embedding it in the physical tail counts (`N=217976794593`, `M=137528045296`, `N-M=80448749297`) proves the relaxed word-side `Qtail mod 5` and endpoint residue sets are full.  The RL221 witness target is `T mod 5 = 3` and has an explicit relaxed word-side match.
- New results / exact ranges / unverified work / corrections: candidate theorem (not yet promoted) that the fixed-count relaxation is saturated for every `q` coprime to 6 through a uniform bound near 283,635; independent derivation/verifier/red team still in progress.  Exact H21 legality is not encoded by this relaxation.  No candidate deletion, physical realization, Gate result, correction, or demotion is claimed.
- Stop-and-repair active: no.
- Next step: finish the general saturation proof/verifier, reconcile the missing legal-H21 language with the physical/arithmetic type guard, and run the required red team before closeout.

This ignored directory is a resumability aid, never proof state or a promotion candidate.
